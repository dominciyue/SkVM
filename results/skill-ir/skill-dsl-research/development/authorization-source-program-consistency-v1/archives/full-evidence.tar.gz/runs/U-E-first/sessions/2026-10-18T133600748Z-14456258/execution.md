# Source program execution

Mode: consume; policy: progressive; status: current.

Source meanings remain unreviewed; this is not request-wide certification.

## Current result

```json
{
  "outcome": {
    "execution": "computed",
    "value": {
      "route_prefix": "documents",
      "action_method": "GET detail download",
      "framework_checks_precede_action": true,
      "configured_global_permissions": "IsAuthenticated + PaperlessObjectPermissions",
      "global_model_permission": "documents.view_document",
      "action_permission_check_applies": false,
      "inherited_object_permission_invoked_for_selected_document": false,
      "request_document": 10,
      "request_lookup_includes_deleted": true,
      "requested_document_is_version": false,
      "authorized_root": 10,
      "authorization_target_owner": 7,
      "root_permission": "view_document",
      "authorization_path": "action-check-skipped-no-user",
      "object_grant_required": null,
      "selected_document": 11,
      "selected_document_owner": 9,
      "selected_differs_from_authorized_root": true,
      "selection_after_authorization": true,
      "authorization_rechecked_for_selected_document": false,
      "version_parameter_value": null,
      "version_parameter_present": false,
      "requested_version_id": null,
      "version_selection_mode": "latest-visible",
      "latest_order_keys": "version_index descending nulls-last, then id descending",
      "invalid_version_outcome": "not-found",
      "file_selection_precedes_representation": true,
      "original_parameter_value": "true",
      "use_archive": false,
      "selected_representation": "original",
      "representation_changes_authorization_target": false,
      "selected_file": "v1-original.pdf",
      "selected_content_type_rule": "selected document mime_type",
      "follow_formatting_effect": "changes response filename only, not selected document or file handle",
      "disposition": "attachment",
      "file_open_failure_outcome": "not-found",
      "runtime_auth_facts_missing": "actual authentication, model-permission, ownership, and guardian object-grant outcomes are not supplied",
      "runtime_storage_fact_missing": "selected file existence/readability and storage backend behavior are not supplied"
    },
    "termination": "return",
    "requiredPremises": [],
    "executionGaps": [],
    "coverageGaps": [
      "DRF authentication and global permission outcomes, guardian object-grant state, and deployment storage availability remain runtime facts outside the finite inputs.",
      "The workflow models the inquiry's authenticated actor; actual ownership and object grants are not assumed.",
      "Further source-visible root, permission, version, and representation branches remain to be authored.",
      {
        "id": "obligation-88ecbbecdc28e051979960bf",
        "anchorId": "anchor-48918d251aae58d0b109b82b",
        "source": {
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "startLine": 336,
          "endLine": 336,
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be"
        },
        "text": "self.get_permissions()",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-bb56d95e506c542a85a91a74",
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
          "startLine": 331,
          "endLine": 342
        },
        "sourceRevision": "4145c92e34c4901c7eb693745a12eb8a730e6d9f805b611fb6f2ebe6974972c6",
        "call": {
          "sourceCallId": "call-2cd5700889f00cb5f97df29b",
          "expression": "self.get_permissions",
          "receiver": "self",
          "receiverClass": "rest_framework.views.APIView",
          "arguments": [],
          "candidateIds": [
            "struct-2088afc91629f90321dd80e8"
          ],
          "resultNames": [],
          "resultBinding": "result-4ff2e00d987f9b58"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
              "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
              "startLine": 420,
              "endLine": 420
            },
            "sourceCallId": "call-f3005f9f445d8cedfb4d8d1e",
            "candidateIds": [
              "struct-bb56d95e506c542a85a91a74"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-d895c89ca8d34ffa4efe1cd5",
        "anchorId": "anchor-d72ad27a5eb99f7add4a9b51",
        "source": {
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "startLine": 337,
          "endLine": 337,
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be"
        },
        "text": "not permission.has_permission(request, self)",
        "kind": "branch-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-bb56d95e506c542a85a91a74",
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
          "startLine": 331,
          "endLine": 342
        },
        "sourceRevision": "4145c92e34c4901c7eb693745a12eb8a730e6d9f805b611fb6f2ebe6974972c6",
        "enclosingBranches": [
          {
            "source": {
              "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
              "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
              "startLine": 336,
              "endLine": 342
            },
            "anchorId": "anchor-8e733082719d0b18502a15ef",
            "text": "for permission in self.get_permissions():\n            if not permission.has_permission(request, self):\n                self.permission_denied(\n                    request,\n                    message=getattr(permission, 'message', None),\n                    code=getattr(permission, 'code', None)\n                )",
            "branch": "body",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
              "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
              "startLine": 420,
              "endLine": 420
            },
            "sourceCallId": "call-f3005f9f445d8cedfb4d8d1e",
            "candidateIds": [
              "struct-bb56d95e506c542a85a91a74"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-fef74d540e1b882acf0c54c1",
        "anchorId": "anchor-94cc1df6b6b8534b8b7986a3",
        "source": {
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "startLine": 337,
          "endLine": 337,
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be"
        },
        "text": "permission.has_permission(request, self)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-bb56d95e506c542a85a91a74",
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
          "startLine": 331,
          "endLine": 342
        },
        "sourceRevision": "4145c92e34c4901c7eb693745a12eb8a730e6d9f805b611fb6f2ebe6974972c6",
        "call": {
          "sourceCallId": "call-681c04b322352a2014ed0188",
          "expression": "permission.has_permission",
          "receiver": "permission",
          "arguments": [
            {
              "expression": "request"
            },
            {
              "expression": "self"
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-92da30ed210facd2"
        },
        "enclosingBranches": [
          {
            "source": {
              "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
              "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
              "startLine": 336,
              "endLine": 342
            },
            "anchorId": "anchor-8e733082719d0b18502a15ef",
            "text": "for permission in self.get_permissions():\n            if not permission.has_permission(request, self):\n                self.permission_denied(\n                    request,\n                    message=getattr(permission, 'message', None),\n                    code=getattr(permission, 'code', None)\n                )",
            "branch": "body",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
              "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
              "startLine": 420,
              "endLine": 420
            },
            "sourceCallId": "call-f3005f9f445d8cedfb4d8d1e",
            "candidateIds": [
              "struct-bb56d95e506c542a85a91a74"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-c2d26e795ce4803cf29e9b78",
        "anchorId": "anchor-da8771f4f836dcae22d57247",
        "source": {
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "startLine": 338,
          "endLine": 342,
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be"
        },
        "text": "self.permission_denied(\n                    request,\n                    message=getattr(permission, 'message', None),\n                    code=getattr(permission, 'code', None)\n                )",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-bb56d95e506c542a85a91a74",
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
          "startLine": 331,
          "endLine": 342
        },
        "sourceRevision": "4145c92e34c4901c7eb693745a12eb8a730e6d9f805b611fb6f2ebe6974972c6",
        "call": {
          "sourceCallId": "call-3720f6ce332e5e7b648d5137",
          "expression": "self.permission_denied",
          "receiver": "self",
          "receiverClass": "rest_framework.views.APIView",
          "arguments": [
            {
              "expression": "request"
            },
            {
              "expression": "getattr(permission, 'message', None)",
              "sourceCallId": "call-4040adcfe6329b089ab156d5",
              "parameterName": "message"
            },
            {
              "expression": "getattr(permission, 'code', None)",
              "sourceCallId": "call-8cdf4906d3d6c2f0816ebcde",
              "parameterName": "code"
            }
          ],
          "candidateIds": [
            "struct-7c973bf5b6fa5c55d4ac0801"
          ],
          "resultNames": [],
          "resultBinding": "result-19629bc1498d49c4"
        },
        "enclosingBranches": [
          {
            "source": {
              "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
              "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
              "startLine": 336,
              "endLine": 342
            },
            "anchorId": "anchor-8e733082719d0b18502a15ef",
            "text": "for permission in self.get_permissions():\n            if not permission.has_permission(request, self):\n                self.permission_denied(\n                    request,\n                    message=getattr(permission, 'message', None),\n                    code=getattr(permission, 'code', None)\n                )",
            "branch": "body",
            "stepIds": []
          },
          {
            "source": {
              "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
              "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
              "startLine": 337,
              "endLine": 337
            },
            "anchorId": "anchor-d72ad27a5eb99f7add4a9b51",
            "text": "not permission.has_permission(request, self)",
            "branch": "true",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
              "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
              "startLine": 420,
              "endLine": 420
            },
            "sourceCallId": "call-f3005f9f445d8cedfb4d8d1e",
            "candidateIds": [
              "struct-bb56d95e506c542a85a91a74"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-9bbe841e3ff2c8a453ac0202",
        "anchorId": "anchor-a06e2cf77252ce4b74ef0268",
        "source": {
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "startLine": 340,
          "endLine": 340,
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be"
        },
        "text": "getattr(permission, 'message', None)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-bb56d95e506c542a85a91a74",
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
          "startLine": 331,
          "endLine": 342
        },
        "sourceRevision": "4145c92e34c4901c7eb693745a12eb8a730e6d9f805b611fb6f2ebe6974972c6",
        "call": {
          "sourceCallId": "call-4040adcfe6329b089ab156d5",
          "expression": "getattr",
          "arguments": [
            {
              "expression": "permission"
            },
            {
              "expression": "'message'",
              "literalKnown": true,
              "literalValue": "message"
            },
            {
              "expression": "None",
              "literalKnown": true,
              "literalValue": null
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-6e1eefdbc255ab6d"
        },
        "enclosingBranches": [
          {
            "source": {
              "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
              "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
              "startLine": 336,
              "endLine": 342
            },
            "anchorId": "anchor-8e733082719d0b18502a15ef",
            "text": "for permission in self.get_permissions():\n            if not permission.has_permission(request, self):\n                self.permission_denied(\n                    request,\n                    message=getattr(permission, 'message', None),\n                    code=getattr(permission, 'code', None)\n                )",
            "branch": "body",
            "stepIds": []
          },
          {
            "source": {
              "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
              "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
              "startLine": 337,
              "endLine": 337
            },
            "anchorId": "anchor-d72ad27a5eb99f7add4a9b51",
            "text": "not permission.has_permission(request, self)",
            "branch": "true",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
              "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
              "startLine": 420,
              "endLine": 420
            },
            "sourceCallId": "call-f3005f9f445d8cedfb4d8d1e",
            "candidateIds": [
              "struct-bb56d95e506c542a85a91a74"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-2badafd7d11825fe54c3b291",
        "anchorId": "anchor-a1039a66127eb8249db32456",
        "source": {
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "startLine": 341,
          "endLine": 341,
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be"
        },
        "text": "getattr(permission, 'code', None)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-bb56d95e506c542a85a91a74",
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
          "startLine": 331,
          "endLine": 342
        },
        "sourceRevision": "4145c92e34c4901c7eb693745a12eb8a730e6d9f805b611fb6f2ebe6974972c6",
        "call": {
          "sourceCallId": "call-8cdf4906d3d6c2f0816ebcde",
          "expression": "getattr",
          "arguments": [
            {
              "expression": "permission"
            },
            {
              "expression": "'code'",
              "literalKnown": true,
              "literalValue": "code"
            },
            {
              "expression": "None",
              "literalKnown": true,
              "literalValue": null
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-bcff10070b0ce890"
        },
        "enclosingBranches": [
          {
            "source": {
              "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
              "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
              "startLine": 336,
              "endLine": 342
            },
            "anchorId": "anchor-8e733082719d0b18502a15ef",
            "text": "for permission in self.get_permissions():\n            if not permission.has_permission(request, self):\n                self.permission_denied(\n                    request,\n                    message=getattr(permission, 'message', None),\n                    code=getattr(permission, 'code', None)\n                )",
            "branch": "body",
            "stepIds": []
          },
          {
            "source": {
              "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
              "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
              "startLine": 337,
              "endLine": 337
            },
            "anchorId": "anchor-d72ad27a5eb99f7add4a9b51",
            "text": "not permission.has_permission(request, self)",
            "branch": "true",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
              "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
              "startLine": 420,
              "endLine": 420
            },
            "sourceCallId": "call-f3005f9f445d8cedfb4d8d1e",
            "candidateIds": [
              "struct-bb56d95e506c542a85a91a74"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-b24ce7acacdc16b989e75f00",
        "anchorId": "anchor-742aa257b997839f18c0927b",
        "source": {
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "startLine": 408,
          "endLine": 408,
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be"
        },
        "text": "self.get_format_suffix(**kwargs)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-b208fbc32f43159be7fc0c41",
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
          "startLine": 404,
          "endLine": 421
        },
        "sourceRevision": "836612b82182aaa7909166b038ed9538371bf696e5ff9f1250a1e45150017611",
        "call": {
          "sourceCallId": "call-413fc416648610deb45cd0c4",
          "expression": "self.get_format_suffix",
          "receiver": "self",
          "receiverClass": "rest_framework.views.APIView",
          "arguments": [
            {
              "expression": "**kwargs",
              "spread": true
            }
          ],
          "candidateIds": [
            "struct-7d11dc180ecf87bbfca43736"
          ],
          "resultNames": [
            "self.format_kwarg"
          ],
          "resultBinding": "result-e211a7283221a106"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
              "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
              "startLine": 514,
              "endLine": 514
            },
            "sourceCallId": "call-53c518ff0a760b555711ccd2",
            "candidateIds": [
              "struct-b208fbc32f43159be7fc0c41"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-b375d4c2a6f00d47dbddbc3c",
        "anchorId": "anchor-19b972b3e68e748584775790",
        "source": {
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "startLine": 411,
          "endLine": 411,
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be"
        },
        "text": "self.perform_content_negotiation(request)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-b208fbc32f43159be7fc0c41",
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
          "startLine": 404,
          "endLine": 421
        },
        "sourceRevision": "836612b82182aaa7909166b038ed9538371bf696e5ff9f1250a1e45150017611",
        "call": {
          "sourceCallId": "call-c530a30caaf675fc6cf141c9",
          "expression": "self.perform_content_negotiation",
          "receiver": "self",
          "receiverClass": "rest_framework.views.APIView",
          "arguments": [
            {
              "expression": "request"
            }
          ],
          "candidateIds": [
            "struct-9cd4a011509acb0c80a7acaa"
          ],
          "resultNames": [
            "neg"
          ],
          "resultBinding": "neg"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
              "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
              "startLine": 514,
              "endLine": 514
            },
            "sourceCallId": "call-53c518ff0a760b555711ccd2",
            "candidateIds": [
              "struct-b208fbc32f43159be7fc0c41"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-20adf9a8c6adbd2d1be27745",
        "anchorId": "anchor-85785ec781777a85060b6326",
        "source": {
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "startLine": 415,
          "endLine": 415,
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be"
        },
        "text": "self.determine_version(request, *args, **kwargs)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-b208fbc32f43159be7fc0c41",
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
          "startLine": 404,
          "endLine": 421
        },
        "sourceRevision": "836612b82182aaa7909166b038ed9538371bf696e5ff9f1250a1e45150017611",
        "call": {
          "sourceCallId": "call-520da6c9dd6ad2df22e4c839",
          "expression": "self.determine_version",
          "receiver": "self",
          "receiverClass": "rest_framework.views.APIView",
          "arguments": [
            {
              "expression": "request"
            },
            {
              "expression": "*args",
              "spread": true
            },
            {
              "expression": "**kwargs",
              "spread": true
            }
          ],
          "candidateIds": [
            "struct-ca664fab2cfb0134d54179b1"
          ],
          "resultNames": [
            "version",
            "scheme"
          ],
          "resultBinding": "version"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
              "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
              "startLine": 514,
              "endLine": 514
            },
            "sourceCallId": "call-53c518ff0a760b555711ccd2",
            "candidateIds": [
              "struct-b208fbc32f43159be7fc0c41"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-dc6ff8e1b1a72d3c74f7f269",
        "anchorId": "anchor-3e5b3fab46d17ccf15dd4365",
        "source": {
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "startLine": 419,
          "endLine": 419,
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be"
        },
        "text": "self.perform_authentication(request)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-b208fbc32f43159be7fc0c41",
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
          "startLine": 404,
          "endLine": 421
        },
        "sourceRevision": "836612b82182aaa7909166b038ed9538371bf696e5ff9f1250a1e45150017611",
        "call": {
          "sourceCallId": "call-bd4859c1a39f34e348168d51",
          "expression": "self.perform_authentication",
          "receiver": "self",
          "receiverClass": "rest_framework.views.APIView",
          "arguments": [
            {
              "expression": "request"
            }
          ],
          "candidateIds": [
            "struct-0fdb7e20cab42d21f7a139d3"
          ],
          "resultNames": [],
          "resultBinding": "result-174b59eb3dd40f0d"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
              "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
              "startLine": 514,
              "endLine": 514
            },
            "sourceCallId": "call-53c518ff0a760b555711ccd2",
            "candidateIds": [
              "struct-b208fbc32f43159be7fc0c41"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-f5dab614383c27bab111e4a2",
        "anchorId": "anchor-18c5d934e64778a9861d12fe",
        "source": {
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "startLine": 420,
          "endLine": 420,
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be"
        },
        "text": "self.check_permissions(request)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-b208fbc32f43159be7fc0c41",
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
          "startLine": 404,
          "endLine": 421
        },
        "sourceRevision": "836612b82182aaa7909166b038ed9538371bf696e5ff9f1250a1e45150017611",
        "call": {
          "sourceCallId": "call-f3005f9f445d8cedfb4d8d1e",
          "expression": "self.check_permissions",
          "receiver": "self",
          "receiverClass": "rest_framework.views.APIView",
          "arguments": [
            {
              "expression": "request"
            }
          ],
          "candidateIds": [
            "struct-bb56d95e506c542a85a91a74"
          ],
          "resultNames": [],
          "resultBinding": "result-2fa4309bddfc269b"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
              "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
              "startLine": 514,
              "endLine": 514
            },
            "sourceCallId": "call-53c518ff0a760b555711ccd2",
            "candidateIds": [
              "struct-b208fbc32f43159be7fc0c41"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-3b8d6a5f7f3d49ddcf8b6893",
        "anchorId": "anchor-e984a427cf36a561e7a6797e",
        "source": {
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "startLine": 421,
          "endLine": 421,
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be"
        },
        "text": "self.check_throttles(request)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-b208fbc32f43159be7fc0c41",
          "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
          "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
          "startLine": 404,
          "endLine": 421
        },
        "sourceRevision": "836612b82182aaa7909166b038ed9538371bf696e5ff9f1250a1e45150017611",
        "call": {
          "sourceCallId": "call-4d879504f9b9f6a51749300f",
          "expression": "self.check_throttles",
          "receiver": "self",
          "receiverClass": "rest_framework.views.APIView",
          "arguments": [
            {
              "expression": "request"
            }
          ],
          "candidateIds": [
            "struct-48a8ded75b9d4aba297dd572"
          ],
          "resultNames": [],
          "resultBinding": "result-057b747de22dbc6d"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
              "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be",
              "startLine": 514,
              "endLine": 514
            },
            "sourceCallId": "call-53c518ff0a760b555711ccd2",
            "candidateIds": [
              "struct-b208fbc32f43159be7fc0c41"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-06e3f91ba61d198e274b8d2c",
        "anchorId": "anchor-bcd6fb3ea8ab7541861b4fe8",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 28,
          "endLine": 28,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "return documents.order_by(F(\"version_index\").desc(nulls_last=True), \"-id\")",
        "kind": "return-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-7747224be8edc53a823a531d",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 23,
          "endLine": 28
        },
        "sourceRevision": "29603ae1b5f0bd0d6908c81fd10eec52b79c3c0c3f5a744e65c3c8a37caac786",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 43,
              "endLine": 45
            },
            "sourceCallId": "call-6ebd74489f747e4352d697fd",
            "candidateIds": [
              "struct-7747224be8edc53a823a531d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 165,
              "endLine": 165
            },
            "sourceCallId": "call-01d408e56bb652717491f2c4",
            "candidateIds": [
              "struct-7747224be8edc53a823a531d"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2302,
              "endLine": 2304
            },
            "sourceCallId": "call-030d44bfb99583f8679efbd9",
            "candidateIds": [
              "struct-7747224be8edc53a823a531d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-5ba3ef043dc29fc5192fa774",
        "anchorId": "anchor-3178b3d5d4059c77ff331f94",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 28,
          "endLine": 28,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "documents.order_by(F(\"version_index\").desc(nulls_last=True), \"-id\")",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-7747224be8edc53a823a531d",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 23,
          "endLine": 28
        },
        "sourceRevision": "29603ae1b5f0bd0d6908c81fd10eec52b79c3c0c3f5a744e65c3c8a37caac786",
        "call": {
          "sourceCallId": "call-45d1b43d2bcb2da7c5b34352",
          "expression": "documents.order_by",
          "receiver": "documents",
          "arguments": [
            {
              "expression": "F(\"version_index\").desc(nulls_last=True)",
              "sourceCallId": "call-98a38ffe57289494c818884b"
            },
            {
              "expression": "\"-id\"",
              "literalKnown": true,
              "literalValue": "-id"
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-f0671bed1fb5a234"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 43,
              "endLine": 45
            },
            "sourceCallId": "call-6ebd74489f747e4352d697fd",
            "candidateIds": [
              "struct-7747224be8edc53a823a531d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 165,
              "endLine": 165
            },
            "sourceCallId": "call-01d408e56bb652717491f2c4",
            "candidateIds": [
              "struct-7747224be8edc53a823a531d"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2302,
              "endLine": 2304
            },
            "sourceCallId": "call-030d44bfb99583f8679efbd9",
            "candidateIds": [
              "struct-7747224be8edc53a823a531d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-6b0c6826677fc0da69ce20c8",
        "anchorId": "anchor-060ce5ec142b43c8e492dc27",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 28,
          "endLine": 28,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "F(\"version_index\")",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-7747224be8edc53a823a531d",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 23,
          "endLine": 28
        },
        "sourceRevision": "29603ae1b5f0bd0d6908c81fd10eec52b79c3c0c3f5a744e65c3c8a37caac786",
        "call": {
          "sourceCallId": "call-98a38ffe57289494c818884b",
          "expression": "F",
          "arguments": [
            {
              "expression": "\"version_index\"",
              "literalKnown": true,
              "literalValue": "version_index"
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-cca92a0f2ce70e06"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 43,
              "endLine": 45
            },
            "sourceCallId": "call-6ebd74489f747e4352d697fd",
            "candidateIds": [
              "struct-7747224be8edc53a823a531d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 165,
              "endLine": 165
            },
            "sourceCallId": "call-01d408e56bb652717491f2c4",
            "candidateIds": [
              "struct-7747224be8edc53a823a531d"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2302,
              "endLine": 2304
            },
            "sourceCallId": "call-030d44bfb99583f8679efbd9",
            "candidateIds": [
              "struct-7747224be8edc53a823a531d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-84eaad2719b15b7978febaff",
        "anchorId": "anchor-d0495390201e30c04295fde0",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 28,
          "endLine": 28,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "F(\"version_index\").desc(nulls_last=True)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-7747224be8edc53a823a531d",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 23,
          "endLine": 28
        },
        "sourceRevision": "29603ae1b5f0bd0d6908c81fd10eec52b79c3c0c3f5a744e65c3c8a37caac786",
        "call": {
          "sourceCallId": "call-98a38ffe57289494c818884b",
          "expression": "F(\"version_index\").desc",
          "receiver": "F(\"version_index\")",
          "arguments": [
            {
              "expression": "True",
              "parameterName": "nulls_last",
              "literalKnown": true,
              "literalValue": true
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-cca92a0f2ce70e06"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 43,
              "endLine": 45
            },
            "sourceCallId": "call-6ebd74489f747e4352d697fd",
            "candidateIds": [
              "struct-7747224be8edc53a823a531d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 165,
              "endLine": 165
            },
            "sourceCallId": "call-01d408e56bb652717491f2c4",
            "candidateIds": [
              "struct-7747224be8edc53a823a531d"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2302,
              "endLine": 2304
            },
            "sourceCallId": "call-030d44bfb99583f8679efbd9",
            "candidateIds": [
              "struct-7747224be8edc53a823a531d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-02132df9812ddcc341436a3f",
        "anchorId": "anchor-e1a721b3738d607a277f1ce9",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 141,
          "endLine": 141,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "hasattr(request, \"query_params\")",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-810e51903be781c2063bfee4",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 140,
          "endLine": 143
        },
        "sourceRevision": "a473168a93ac230c6c4365315fae3e88d6949b5b3d69a30a694a1164f3abf6af",
        "call": {
          "sourceCallId": "call-7e95ddd597c97d0657c5961f",
          "expression": "hasattr",
          "arguments": [
            {
              "expression": "request"
            },
            {
              "expression": "\"query_params\"",
              "literalKnown": true,
              "literalValue": "query_params"
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-a9a465d08a70ac71"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 175,
              "endLine": 175
            },
            "sourceCallId": "call-1fd86d2ee68c778d5d2910a0",
            "candidateIds": [
              "struct-810e51903be781c2063bfee4"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 205,
              "endLine": 205
            },
            "sourceCallId": "call-b270183c49a7eee02dc7e46e",
            "candidateIds": [
              "struct-810e51903be781c2063bfee4"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1376,
              "endLine": 1376
            },
            "sourceCallId": "call-849c9bed36a52d17d377b5a5",
            "candidateIds": [
              "struct-810e51903be781c2063bfee4"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1396,
              "endLine": 1396
            },
            "sourceCallId": "call-762faef438df4c815df72179",
            "candidateIds": [
              "struct-810e51903be781c2063bfee4"
            ],
            "state": "current",
            "enclosingBranches": [
              {
                "source": {
                  "path": "src/documents/views.py",
                  "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
                  "startLine": 1395,
                  "endLine": 1396
                },
                "anchorId": "anchor-90a70d83c1f0f382a2fe8496",
                "text": "request_doc.root_document_id is not None\n            and get_request_version_param(request) is None",
                "branch": "and-right",
                "stepIds": []
              }
            ]
          }
        ]
      },
      {
        "id": "obligation-7a4cddefb968033b7e4ada83",
        "anchorId": "anchor-e6e622ef1dab2f04b1707cac",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 141,
          "endLine": 141,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "hasattr(request, \"query_params\")",
        "kind": "branch-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-810e51903be781c2063bfee4",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 140,
          "endLine": 143
        },
        "sourceRevision": "a473168a93ac230c6c4365315fae3e88d6949b5b3d69a30a694a1164f3abf6af",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 175,
              "endLine": 175
            },
            "sourceCallId": "call-1fd86d2ee68c778d5d2910a0",
            "candidateIds": [
              "struct-810e51903be781c2063bfee4"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 205,
              "endLine": 205
            },
            "sourceCallId": "call-b270183c49a7eee02dc7e46e",
            "candidateIds": [
              "struct-810e51903be781c2063bfee4"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1376,
              "endLine": 1376
            },
            "sourceCallId": "call-849c9bed36a52d17d377b5a5",
            "candidateIds": [
              "struct-810e51903be781c2063bfee4"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1396,
              "endLine": 1396
            },
            "sourceCallId": "call-762faef438df4c815df72179",
            "candidateIds": [
              "struct-810e51903be781c2063bfee4"
            ],
            "state": "current",
            "enclosingBranches": [
              {
                "source": {
                  "path": "src/documents/views.py",
                  "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
                  "startLine": 1395,
                  "endLine": 1396
                },
                "anchorId": "anchor-90a70d83c1f0f382a2fe8496",
                "text": "request_doc.root_document_id is not None\n            and get_request_version_param(request) is None",
                "branch": "and-right",
                "stepIds": []
              }
            ]
          }
        ]
      },
      {
        "id": "obligation-6b12817a28f84eec833ebbb6",
        "anchorId": "anchor-990464db5f820898757bfd8e",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 142,
          "endLine": 142,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "return request.query_params.get(\"version\")",
        "kind": "return-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-810e51903be781c2063bfee4",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 140,
          "endLine": 143
        },
        "sourceRevision": "a473168a93ac230c6c4365315fae3e88d6949b5b3d69a30a694a1164f3abf6af",
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 141,
              "endLine": 141
            },
            "anchorId": "anchor-e6e622ef1dab2f04b1707cac",
            "text": "hasattr(request, \"query_params\")",
            "branch": "true",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 175,
              "endLine": 175
            },
            "sourceCallId": "call-1fd86d2ee68c778d5d2910a0",
            "candidateIds": [
              "struct-810e51903be781c2063bfee4"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 205,
              "endLine": 205
            },
            "sourceCallId": "call-b270183c49a7eee02dc7e46e",
            "candidateIds": [
              "struct-810e51903be781c2063bfee4"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1376,
              "endLine": 1376
            },
            "sourceCallId": "call-849c9bed36a52d17d377b5a5",
            "candidateIds": [
              "struct-810e51903be781c2063bfee4"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1396,
              "endLine": 1396
            },
            "sourceCallId": "call-762faef438df4c815df72179",
            "candidateIds": [
              "struct-810e51903be781c2063bfee4"
            ],
            "state": "current",
            "enclosingBranches": [
              {
                "source": {
                  "path": "src/documents/views.py",
                  "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
                  "startLine": 1395,
                  "endLine": 1396
                },
                "anchorId": "anchor-90a70d83c1f0f382a2fe8496",
                "text": "request_doc.root_document_id is not None\n            and get_request_version_param(request) is None",
                "branch": "and-right",
                "stepIds": []
              }
            ]
          }
        ]
      },
      {
        "id": "obligation-58044f9b0b797bdc46eee429",
        "anchorId": "anchor-be6de5a93ec193adf6280a2b",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 142,
          "endLine": 142,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "request.query_params.get(\"version\")",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-810e51903be781c2063bfee4",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 140,
          "endLine": 143
        },
        "sourceRevision": "a473168a93ac230c6c4365315fae3e88d6949b5b3d69a30a694a1164f3abf6af",
        "call": {
          "sourceCallId": "call-5686412d2882b8f703adf93a",
          "expression": "request.query_params.get",
          "receiver": "request.query_params",
          "arguments": [
            {
              "expression": "\"version\"",
              "literalKnown": true,
              "literalValue": "version"
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-eae65e679b233695"
        },
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 141,
              "endLine": 141
            },
            "anchorId": "anchor-e6e622ef1dab2f04b1707cac",
            "text": "hasattr(request, \"query_params\")",
            "branch": "true",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 175,
              "endLine": 175
            },
            "sourceCallId": "call-1fd86d2ee68c778d5d2910a0",
            "candidateIds": [
              "struct-810e51903be781c2063bfee4"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 205,
              "endLine": 205
            },
            "sourceCallId": "call-b270183c49a7eee02dc7e46e",
            "candidateIds": [
              "struct-810e51903be781c2063bfee4"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1376,
              "endLine": 1376
            },
            "sourceCallId": "call-849c9bed36a52d17d377b5a5",
            "candidateIds": [
              "struct-810e51903be781c2063bfee4"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1396,
              "endLine": 1396
            },
            "sourceCallId": "call-762faef438df4c815df72179",
            "candidateIds": [
              "struct-810e51903be781c2063bfee4"
            ],
            "state": "current",
            "enclosingBranches": [
              {
                "source": {
                  "path": "src/documents/views.py",
                  "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
                  "startLine": 1395,
                  "endLine": 1396
                },
                "anchorId": "anchor-90a70d83c1f0f382a2fe8496",
                "text": "request_doc.root_document_id is not None\n            and get_request_version_param(request) is None",
                "branch": "and-right",
                "stepIds": []
              }
            ]
          }
        ]
      },
      {
        "id": "obligation-0a83e0c8da463ecc54640753",
        "anchorId": "anchor-66a11b842e81e2079c051fcb",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 143,
          "endLine": 143,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "return None",
        "kind": "return-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-810e51903be781c2063bfee4",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 140,
          "endLine": 143
        },
        "sourceRevision": "a473168a93ac230c6c4365315fae3e88d6949b5b3d69a30a694a1164f3abf6af",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 175,
              "endLine": 175
            },
            "sourceCallId": "call-1fd86d2ee68c778d5d2910a0",
            "candidateIds": [
              "struct-810e51903be781c2063bfee4"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 205,
              "endLine": 205
            },
            "sourceCallId": "call-b270183c49a7eee02dc7e46e",
            "candidateIds": [
              "struct-810e51903be781c2063bfee4"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1376,
              "endLine": 1376
            },
            "sourceCallId": "call-849c9bed36a52d17d377b5a5",
            "candidateIds": [
              "struct-810e51903be781c2063bfee4"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1396,
              "endLine": 1396
            },
            "sourceCallId": "call-762faef438df4c815df72179",
            "candidateIds": [
              "struct-810e51903be781c2063bfee4"
            ],
            "state": "current",
            "enclosingBranches": [
              {
                "source": {
                  "path": "src/documents/views.py",
                  "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
                  "startLine": 1395,
                  "endLine": 1396
                },
                "anchorId": "anchor-90a70d83c1f0f382a2fe8496",
                "text": "request_doc.root_document_id is not None\n            and get_request_version_param(request) is None",
                "branch": "and-right",
                "stepIds": []
              }
            ]
          }
        ]
      },
      {
        "id": "obligation-21096bf68f93f8215e2c36df",
        "anchorId": "anchor-b75e2064f39d18969bb7a9d6",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 149,
          "endLine": 149,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "doc.root_document_id is None",
        "kind": "branch-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-7ab1297ea3f05dc30ca55b3d",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 146,
          "endLine": 156
        },
        "sourceRevision": "53251f5c359ece2630f27e9e384dbe174775ccdfba4460fdd9ee2e66205396bb",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/bulk_edit.py",
              "sha256": "6b0b7b4542db54d7e01912c02eb8a4c337db3618c85d6663a9d6957c6509eabc",
              "startLine": 104,
              "endLine": 104
            },
            "sourceCallId": "call-075f2a40197159aa20f6eaf1",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 204,
              "endLine": 204
            },
            "sourceCallId": "call-2772e0dca817ecd5142ed625",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1254,
              "endLine": 1254
            },
            "sourceCallId": "call-791b36f2f7856a45b70a5ac6",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1417,
              "endLine": 1420
            },
            "sourceCallId": "call-1b6611fb1500ce49654386e3",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2156,
              "endLine": 2156
            },
            "sourceCallId": "call-935e952de2eeb2b011acaf9f",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2220,
              "endLine": 2220
            },
            "sourceCallId": "call-320d7148c98b54cbaa99b96f",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2971,
              "endLine": 2971
            },
            "sourceCallId": "call-df1f24f8e47ca9c915b4cffa",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4107,
              "endLine": 4107
            },
            "sourceCallId": "call-a80f722f81f5fd49515d86c3",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-4bc711198e2d35a8cc50600a",
        "anchorId": "anchor-d7acb0efeac7bef83a1caf1e",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 150,
          "endLine": 150,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "return doc",
        "kind": "return-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-7ab1297ea3f05dc30ca55b3d",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 146,
          "endLine": 156
        },
        "sourceRevision": "53251f5c359ece2630f27e9e384dbe174775ccdfba4460fdd9ee2e66205396bb",
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 149,
              "endLine": 149
            },
            "anchorId": "anchor-b75e2064f39d18969bb7a9d6",
            "text": "doc.root_document_id is None",
            "branch": "true",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/bulk_edit.py",
              "sha256": "6b0b7b4542db54d7e01912c02eb8a4c337db3618c85d6663a9d6957c6509eabc",
              "startLine": 104,
              "endLine": 104
            },
            "sourceCallId": "call-075f2a40197159aa20f6eaf1",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 204,
              "endLine": 204
            },
            "sourceCallId": "call-2772e0dca817ecd5142ed625",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1254,
              "endLine": 1254
            },
            "sourceCallId": "call-791b36f2f7856a45b70a5ac6",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1417,
              "endLine": 1420
            },
            "sourceCallId": "call-1b6611fb1500ce49654386e3",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2156,
              "endLine": 2156
            },
            "sourceCallId": "call-935e952de2eeb2b011acaf9f",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2220,
              "endLine": 2220
            },
            "sourceCallId": "call-320d7148c98b54cbaa99b96f",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2971,
              "endLine": 2971
            },
            "sourceCallId": "call-df1f24f8e47ca9c915b4cffa",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4107,
              "endLine": 4107
            },
            "sourceCallId": "call-a80f722f81f5fd49515d86c3",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-256ef80c1898a20bb51d8408",
        "anchorId": "anchor-67f01ed7c603c07feda5399a",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 151,
          "endLine": 151,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "doc.root_document is not None",
        "kind": "branch-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-7ab1297ea3f05dc30ca55b3d",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 146,
          "endLine": 156
        },
        "sourceRevision": "53251f5c359ece2630f27e9e384dbe174775ccdfba4460fdd9ee2e66205396bb",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/bulk_edit.py",
              "sha256": "6b0b7b4542db54d7e01912c02eb8a4c337db3618c85d6663a9d6957c6509eabc",
              "startLine": 104,
              "endLine": 104
            },
            "sourceCallId": "call-075f2a40197159aa20f6eaf1",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 204,
              "endLine": 204
            },
            "sourceCallId": "call-2772e0dca817ecd5142ed625",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1254,
              "endLine": 1254
            },
            "sourceCallId": "call-791b36f2f7856a45b70a5ac6",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1417,
              "endLine": 1420
            },
            "sourceCallId": "call-1b6611fb1500ce49654386e3",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2156,
              "endLine": 2156
            },
            "sourceCallId": "call-935e952de2eeb2b011acaf9f",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2220,
              "endLine": 2220
            },
            "sourceCallId": "call-320d7148c98b54cbaa99b96f",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2971,
              "endLine": 2971
            },
            "sourceCallId": "call-df1f24f8e47ca9c915b4cffa",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4107,
              "endLine": 4107
            },
            "sourceCallId": "call-a80f722f81f5fd49515d86c3",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-5cb48316cdba057d46143d97",
        "anchorId": "anchor-83707ebb81869a50d41c5eeb",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 152,
          "endLine": 152,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "return doc.root_document",
        "kind": "return-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-7ab1297ea3f05dc30ca55b3d",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 146,
          "endLine": 156
        },
        "sourceRevision": "53251f5c359ece2630f27e9e384dbe174775ccdfba4460fdd9ee2e66205396bb",
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 151,
              "endLine": 151
            },
            "anchorId": "anchor-67f01ed7c603c07feda5399a",
            "text": "doc.root_document is not None",
            "branch": "true",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/bulk_edit.py",
              "sha256": "6b0b7b4542db54d7e01912c02eb8a4c337db3618c85d6663a9d6957c6509eabc",
              "startLine": 104,
              "endLine": 104
            },
            "sourceCallId": "call-075f2a40197159aa20f6eaf1",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 204,
              "endLine": 204
            },
            "sourceCallId": "call-2772e0dca817ecd5142ed625",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1254,
              "endLine": 1254
            },
            "sourceCallId": "call-791b36f2f7856a45b70a5ac6",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1417,
              "endLine": 1420
            },
            "sourceCallId": "call-1b6611fb1500ce49654386e3",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2156,
              "endLine": 2156
            },
            "sourceCallId": "call-935e952de2eeb2b011acaf9f",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2220,
              "endLine": 2220
            },
            "sourceCallId": "call-320d7148c98b54cbaa99b96f",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2971,
              "endLine": 2971
            },
            "sourceCallId": "call-df1f24f8e47ca9c915b4cffa",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4107,
              "endLine": 4107
            },
            "sourceCallId": "call-a80f722f81f5fd49515d86c3",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-fec3809d362043f6f8dce8ac",
        "anchorId": "anchor-1be0d4b30de716b64a7a598f",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 154,
          "endLine": 154,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "_document_manager(include_deleted=include_deleted)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-7ab1297ea3f05dc30ca55b3d",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 146,
          "endLine": 156
        },
        "sourceRevision": "53251f5c359ece2630f27e9e384dbe174775ccdfba4460fdd9ee2e66205396bb",
        "call": {
          "sourceCallId": "call-6908c1be8e1964b8f65792f6",
          "expression": "_document_manager",
          "arguments": [
            {
              "expression": "include_deleted",
              "parameterName": "include_deleted"
            }
          ],
          "candidateIds": [
            "struct-e227d7ee179daabbf744e8e9"
          ],
          "resultNames": [
            "manager"
          ],
          "resultBinding": "manager"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/bulk_edit.py",
              "sha256": "6b0b7b4542db54d7e01912c02eb8a4c337db3618c85d6663a9d6957c6509eabc",
              "startLine": 104,
              "endLine": 104
            },
            "sourceCallId": "call-075f2a40197159aa20f6eaf1",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 204,
              "endLine": 204
            },
            "sourceCallId": "call-2772e0dca817ecd5142ed625",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1254,
              "endLine": 1254
            },
            "sourceCallId": "call-791b36f2f7856a45b70a5ac6",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1417,
              "endLine": 1420
            },
            "sourceCallId": "call-1b6611fb1500ce49654386e3",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2156,
              "endLine": 2156
            },
            "sourceCallId": "call-935e952de2eeb2b011acaf9f",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2220,
              "endLine": 2220
            },
            "sourceCallId": "call-320d7148c98b54cbaa99b96f",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2971,
              "endLine": 2971
            },
            "sourceCallId": "call-df1f24f8e47ca9c915b4cffa",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4107,
              "endLine": 4107
            },
            "sourceCallId": "call-a80f722f81f5fd49515d86c3",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-c8883607777d9d88cbe4e91e",
        "anchorId": "anchor-0f883c6aa07444659cb89782",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 155,
          "endLine": 155,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "manager.only(\"id\")",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-7ab1297ea3f05dc30ca55b3d",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 146,
          "endLine": 156
        },
        "sourceRevision": "53251f5c359ece2630f27e9e384dbe174775ccdfba4460fdd9ee2e66205396bb",
        "call": {
          "sourceCallId": "call-8c7a1927bc80727c1dd13b5b",
          "expression": "manager.only",
          "receiver": "manager",
          "arguments": [
            {
              "expression": "\"id\"",
              "literalKnown": true,
              "literalValue": "id"
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-c6152ecc3e9d0086"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/bulk_edit.py",
              "sha256": "6b0b7b4542db54d7e01912c02eb8a4c337db3618c85d6663a9d6957c6509eabc",
              "startLine": 104,
              "endLine": 104
            },
            "sourceCallId": "call-075f2a40197159aa20f6eaf1",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 204,
              "endLine": 204
            },
            "sourceCallId": "call-2772e0dca817ecd5142ed625",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1254,
              "endLine": 1254
            },
            "sourceCallId": "call-791b36f2f7856a45b70a5ac6",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1417,
              "endLine": 1420
            },
            "sourceCallId": "call-1b6611fb1500ce49654386e3",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2156,
              "endLine": 2156
            },
            "sourceCallId": "call-935e952de2eeb2b011acaf9f",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2220,
              "endLine": 2220
            },
            "sourceCallId": "call-320d7148c98b54cbaa99b96f",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2971,
              "endLine": 2971
            },
            "sourceCallId": "call-df1f24f8e47ca9c915b4cffa",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4107,
              "endLine": 4107
            },
            "sourceCallId": "call-a80f722f81f5fd49515d86c3",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-ddd342baa3ba5b12a989c0b3",
        "anchorId": "anchor-337cadc575be01201161c3c4",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 155,
          "endLine": 155,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "manager.only(\"id\").filter(id=doc.root_document_id)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-7ab1297ea3f05dc30ca55b3d",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 146,
          "endLine": 156
        },
        "sourceRevision": "53251f5c359ece2630f27e9e384dbe174775ccdfba4460fdd9ee2e66205396bb",
        "call": {
          "sourceCallId": "call-8c7a1927bc80727c1dd13b5b",
          "expression": "manager.only(\"id\").filter",
          "receiver": "manager.only(\"id\")",
          "arguments": [
            {
              "expression": "doc.root_document_id",
              "parameterName": "id"
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-c6152ecc3e9d0086"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/bulk_edit.py",
              "sha256": "6b0b7b4542db54d7e01912c02eb8a4c337db3618c85d6663a9d6957c6509eabc",
              "startLine": 104,
              "endLine": 104
            },
            "sourceCallId": "call-075f2a40197159aa20f6eaf1",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 204,
              "endLine": 204
            },
            "sourceCallId": "call-2772e0dca817ecd5142ed625",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1254,
              "endLine": 1254
            },
            "sourceCallId": "call-791b36f2f7856a45b70a5ac6",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1417,
              "endLine": 1420
            },
            "sourceCallId": "call-1b6611fb1500ce49654386e3",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2156,
              "endLine": 2156
            },
            "sourceCallId": "call-935e952de2eeb2b011acaf9f",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2220,
              "endLine": 2220
            },
            "sourceCallId": "call-320d7148c98b54cbaa99b96f",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2971,
              "endLine": 2971
            },
            "sourceCallId": "call-df1f24f8e47ca9c915b4cffa",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4107,
              "endLine": 4107
            },
            "sourceCallId": "call-a80f722f81f5fd49515d86c3",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-46d9d55473d312e61f189ed5",
        "anchorId": "anchor-dd12bc4558f38ba1f22a65e4",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 155,
          "endLine": 155,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "manager.only(\"id\").filter(id=doc.root_document_id).first()",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-7ab1297ea3f05dc30ca55b3d",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 146,
          "endLine": 156
        },
        "sourceRevision": "53251f5c359ece2630f27e9e384dbe174775ccdfba4460fdd9ee2e66205396bb",
        "call": {
          "sourceCallId": "call-8c7a1927bc80727c1dd13b5b",
          "expression": "manager.only(\"id\").filter(id=doc.root_document_id).first",
          "receiver": "manager.only(\"id\").filter(id=doc.root_document_id)",
          "arguments": [],
          "candidateIds": [],
          "resultNames": [
            "root_doc"
          ],
          "resultBinding": "root_doc"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/bulk_edit.py",
              "sha256": "6b0b7b4542db54d7e01912c02eb8a4c337db3618c85d6663a9d6957c6509eabc",
              "startLine": 104,
              "endLine": 104
            },
            "sourceCallId": "call-075f2a40197159aa20f6eaf1",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 204,
              "endLine": 204
            },
            "sourceCallId": "call-2772e0dca817ecd5142ed625",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1254,
              "endLine": 1254
            },
            "sourceCallId": "call-791b36f2f7856a45b70a5ac6",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1417,
              "endLine": 1420
            },
            "sourceCallId": "call-1b6611fb1500ce49654386e3",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2156,
              "endLine": 2156
            },
            "sourceCallId": "call-935e952de2eeb2b011acaf9f",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2220,
              "endLine": 2220
            },
            "sourceCallId": "call-320d7148c98b54cbaa99b96f",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2971,
              "endLine": 2971
            },
            "sourceCallId": "call-df1f24f8e47ca9c915b4cffa",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4107,
              "endLine": 4107
            },
            "sourceCallId": "call-a80f722f81f5fd49515d86c3",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-f9b36f97b7382568793183f0",
        "anchorId": "anchor-5ca1a70c0ef8592b0b43b049",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 156,
          "endLine": 156,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "return root_doc or doc",
        "kind": "return-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-7ab1297ea3f05dc30ca55b3d",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 146,
          "endLine": 156
        },
        "sourceRevision": "53251f5c359ece2630f27e9e384dbe174775ccdfba4460fdd9ee2e66205396bb",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/bulk_edit.py",
              "sha256": "6b0b7b4542db54d7e01912c02eb8a4c337db3618c85d6663a9d6957c6509eabc",
              "startLine": 104,
              "endLine": 104
            },
            "sourceCallId": "call-075f2a40197159aa20f6eaf1",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 204,
              "endLine": 204
            },
            "sourceCallId": "call-2772e0dca817ecd5142ed625",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1254,
              "endLine": 1254
            },
            "sourceCallId": "call-791b36f2f7856a45b70a5ac6",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1417,
              "endLine": 1420
            },
            "sourceCallId": "call-1b6611fb1500ce49654386e3",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2156,
              "endLine": 2156
            },
            "sourceCallId": "call-935e952de2eeb2b011acaf9f",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2220,
              "endLine": 2220
            },
            "sourceCallId": "call-320d7148c98b54cbaa99b96f",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 2971,
              "endLine": 2971
            },
            "sourceCallId": "call-df1f24f8e47ca9c915b4cffa",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4107,
              "endLine": 4107
            },
            "sourceCallId": "call-a80f722f81f5fd49515d86c3",
            "candidateIds": [
              "struct-7ab1297ea3f05dc30ca55b3d"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-f53cd663cac0400399c6db2d",
        "anchorId": "anchor-76b389b3f895e4f492db4167",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 164,
          "endLine": 164,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "_document_manager(include_deleted=include_deleted)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-10ff580c76a7c53d792e0822",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 159,
          "endLine": 166
        },
        "sourceRevision": "307d354ece308b675f0edd32bdfeb703a64419754cccbebd96bcd281907afd51",
        "call": {
          "sourceCallId": "call-e5fa22ca003e938de6e0e393",
          "expression": "_document_manager",
          "arguments": [
            {
              "expression": "include_deleted",
              "parameterName": "include_deleted"
            }
          ],
          "candidateIds": [
            "struct-e227d7ee179daabbf744e8e9"
          ],
          "resultNames": [
            "manager"
          ],
          "resultBinding": "manager"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/bulk_edit.py",
              "sha256": "6b0b7b4542db54d7e01912c02eb8a4c337db3618c85d6663a9d6957c6509eabc",
              "startLine": 115,
              "endLine": 115
            },
            "sourceCallId": "call-c46d2e253455944e98c54473",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 178,
              "endLine": 181
            },
            "sourceCallId": "call-77bf7b9a3e2f975a454a8316",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "current",
            "enclosingBranches": [
              {
                "source": {
                  "path": "src/documents/versioning.py",
                  "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
                  "startLine": 176,
                  "endLine": 176
                },
                "anchorId": "anchor-6340156d3c7121160d1247d1",
                "text": "not version_param",
                "branch": "true",
                "stepIds": []
              }
            ]
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 213,
              "endLine": 216
            },
            "sourceCallId": "call-f6f6f8bb96d5e35655aeb589",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1289,
              "endLine": 1289
            },
            "sourceCallId": "call-a46010d51d8aba69579c81a6",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4111,
              "endLine": 4113
            },
            "sourceCallId": "call-5f1845dcbdea3d456e5594f7",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-8bddf5fe0d691479f97ca4b8",
        "anchorId": "anchor-660927d7b225ca0a64774364",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 165,
          "endLine": 165,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "versions_newest_first(manager.filter(root_document=root_doc)).first()",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-10ff580c76a7c53d792e0822",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 159,
          "endLine": 166
        },
        "sourceRevision": "307d354ece308b675f0edd32bdfeb703a64419754cccbebd96bcd281907afd51",
        "call": {
          "sourceCallId": "call-01d408e56bb652717491f2c4",
          "expression": "versions_newest_first(manager.filter(root_document=root_doc)).first",
          "receiver": "versions_newest_first(manager.filter(root_document=root_doc))",
          "arguments": [],
          "candidateIds": [],
          "resultNames": [
            "latest"
          ],
          "resultBinding": "latest"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/bulk_edit.py",
              "sha256": "6b0b7b4542db54d7e01912c02eb8a4c337db3618c85d6663a9d6957c6509eabc",
              "startLine": 115,
              "endLine": 115
            },
            "sourceCallId": "call-c46d2e253455944e98c54473",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 178,
              "endLine": 181
            },
            "sourceCallId": "call-77bf7b9a3e2f975a454a8316",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "current",
            "enclosingBranches": [
              {
                "source": {
                  "path": "src/documents/versioning.py",
                  "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
                  "startLine": 176,
                  "endLine": 176
                },
                "anchorId": "anchor-6340156d3c7121160d1247d1",
                "text": "not version_param",
                "branch": "true",
                "stepIds": []
              }
            ]
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 213,
              "endLine": 216
            },
            "sourceCallId": "call-f6f6f8bb96d5e35655aeb589",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1289,
              "endLine": 1289
            },
            "sourceCallId": "call-a46010d51d8aba69579c81a6",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4111,
              "endLine": 4113
            },
            "sourceCallId": "call-5f1845dcbdea3d456e5594f7",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-32c65c7399ede7524ab681e7",
        "anchorId": "anchor-9e8be0afc10cc81a8ff461d1",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 165,
          "endLine": 165,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "versions_newest_first(manager.filter(root_document=root_doc))",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-10ff580c76a7c53d792e0822",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 159,
          "endLine": 166
        },
        "sourceRevision": "307d354ece308b675f0edd32bdfeb703a64419754cccbebd96bcd281907afd51",
        "call": {
          "sourceCallId": "call-01d408e56bb652717491f2c4",
          "expression": "versions_newest_first",
          "arguments": [
            {
              "expression": "manager.filter(root_document=root_doc)",
              "sourceCallId": "call-1215b424b8f1800699d973cd"
            }
          ],
          "candidateIds": [
            "struct-7747224be8edc53a823a531d"
          ],
          "resultNames": [],
          "resultBinding": "result-6b6f00c3ad4338f3"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/bulk_edit.py",
              "sha256": "6b0b7b4542db54d7e01912c02eb8a4c337db3618c85d6663a9d6957c6509eabc",
              "startLine": 115,
              "endLine": 115
            },
            "sourceCallId": "call-c46d2e253455944e98c54473",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 178,
              "endLine": 181
            },
            "sourceCallId": "call-77bf7b9a3e2f975a454a8316",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "current",
            "enclosingBranches": [
              {
                "source": {
                  "path": "src/documents/versioning.py",
                  "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
                  "startLine": 176,
                  "endLine": 176
                },
                "anchorId": "anchor-6340156d3c7121160d1247d1",
                "text": "not version_param",
                "branch": "true",
                "stepIds": []
              }
            ]
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 213,
              "endLine": 216
            },
            "sourceCallId": "call-f6f6f8bb96d5e35655aeb589",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1289,
              "endLine": 1289
            },
            "sourceCallId": "call-a46010d51d8aba69579c81a6",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4111,
              "endLine": 4113
            },
            "sourceCallId": "call-5f1845dcbdea3d456e5594f7",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-ce801cdb4b2f2ae2b9c6ccb7",
        "anchorId": "anchor-97fb8875c0b1e2349d9dc9ef",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 165,
          "endLine": 165,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "manager.filter(root_document=root_doc)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-10ff580c76a7c53d792e0822",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 159,
          "endLine": 166
        },
        "sourceRevision": "307d354ece308b675f0edd32bdfeb703a64419754cccbebd96bcd281907afd51",
        "call": {
          "sourceCallId": "call-1215b424b8f1800699d973cd",
          "expression": "manager.filter",
          "receiver": "manager",
          "arguments": [
            {
              "expression": "root_doc",
              "parameterName": "root_document"
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-ce3ef59db8c6331b"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/bulk_edit.py",
              "sha256": "6b0b7b4542db54d7e01912c02eb8a4c337db3618c85d6663a9d6957c6509eabc",
              "startLine": 115,
              "endLine": 115
            },
            "sourceCallId": "call-c46d2e253455944e98c54473",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 178,
              "endLine": 181
            },
            "sourceCallId": "call-77bf7b9a3e2f975a454a8316",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "current",
            "enclosingBranches": [
              {
                "source": {
                  "path": "src/documents/versioning.py",
                  "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
                  "startLine": 176,
                  "endLine": 176
                },
                "anchorId": "anchor-6340156d3c7121160d1247d1",
                "text": "not version_param",
                "branch": "true",
                "stepIds": []
              }
            ]
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 213,
              "endLine": 216
            },
            "sourceCallId": "call-f6f6f8bb96d5e35655aeb589",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1289,
              "endLine": 1289
            },
            "sourceCallId": "call-a46010d51d8aba69579c81a6",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4111,
              "endLine": 4113
            },
            "sourceCallId": "call-5f1845dcbdea3d456e5594f7",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-fa090a6682c41172fd6b1923",
        "anchorId": "anchor-7c861ffe30a11aa399694081",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 166,
          "endLine": 166,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "return latest or root_doc",
        "kind": "return-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-10ff580c76a7c53d792e0822",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 159,
          "endLine": 166
        },
        "sourceRevision": "307d354ece308b675f0edd32bdfeb703a64419754cccbebd96bcd281907afd51",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/bulk_edit.py",
              "sha256": "6b0b7b4542db54d7e01912c02eb8a4c337db3618c85d6663a9d6957c6509eabc",
              "startLine": 115,
              "endLine": 115
            },
            "sourceCallId": "call-c46d2e253455944e98c54473",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 178,
              "endLine": 181
            },
            "sourceCallId": "call-77bf7b9a3e2f975a454a8316",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "current",
            "enclosingBranches": [
              {
                "source": {
                  "path": "src/documents/versioning.py",
                  "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
                  "startLine": 176,
                  "endLine": 176
                },
                "anchorId": "anchor-6340156d3c7121160d1247d1",
                "text": "not version_param",
                "branch": "true",
                "stepIds": []
              }
            ]
          },
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 213,
              "endLine": 216
            },
            "sourceCallId": "call-f6f6f8bb96d5e35655aeb589",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1289,
              "endLine": 1289
            },
            "sourceCallId": "call-a46010d51d8aba69579c81a6",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4111,
              "endLine": 4113
            },
            "sourceCallId": "call-5f1845dcbdea3d456e5594f7",
            "candidateIds": [
              "struct-10ff580c76a7c53d792e0822"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-c47881f7e542166a391980f6",
        "anchorId": "anchor-ff059590592cb350ecc8080a",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 175,
          "endLine": 175,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "get_request_version_param(request)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-93fdecbcd742d5f8f0082c60",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 169,
          "endLine": 195
        },
        "sourceRevision": "ae4d06ea8444588b2ec1403b938a9ce41ed5e552713b65acd756ed6f839eea8f",
        "call": {
          "sourceCallId": "call-1fd86d2ee68c778d5d2910a0",
          "expression": "get_request_version_param",
          "arguments": [
            {
              "expression": "request"
            }
          ],
          "candidateIds": [
            "struct-810e51903be781c2063bfee4"
          ],
          "resultNames": [
            "version_param"
          ],
          "resultBinding": "version_param"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 206,
              "endLine": 210
            },
            "sourceCallId": "call-52b0c18ef6069938221ad495",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1377,
              "endLine": 1381
            },
            "sourceCallId": "call-da3968f2ad4de57a86787375",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-0ade251e52adc93c4c70a090",
        "anchorId": "anchor-6340156d3c7121160d1247d1",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 176,
          "endLine": 176,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "not version_param",
        "kind": "branch-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-93fdecbcd742d5f8f0082c60",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 169,
          "endLine": 195
        },
        "sourceRevision": "ae4d06ea8444588b2ec1403b938a9ce41ed5e552713b65acd756ed6f839eea8f",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 206,
              "endLine": 210
            },
            "sourceCallId": "call-52b0c18ef6069938221ad495",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1377,
              "endLine": 1381
            },
            "sourceCallId": "call-da3968f2ad4de57a86787375",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-ad4e805198dba9ee6e0ee50f",
        "anchorId": "anchor-c3f9f79dcbdfe1a9984c5ed0",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 177,
          "endLine": 182,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "return VersionResolution(\n            document=get_latest_version_for_root(\n                root_doc,\n                include_deleted=include_deleted,\n            ),\n        )",
        "kind": "return-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-93fdecbcd742d5f8f0082c60",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 169,
          "endLine": 195
        },
        "sourceRevision": "ae4d06ea8444588b2ec1403b938a9ce41ed5e552713b65acd756ed6f839eea8f",
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 176,
              "endLine": 176
            },
            "anchorId": "anchor-6340156d3c7121160d1247d1",
            "text": "not version_param",
            "branch": "true",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 206,
              "endLine": 210
            },
            "sourceCallId": "call-52b0c18ef6069938221ad495",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1377,
              "endLine": 1381
            },
            "sourceCallId": "call-da3968f2ad4de57a86787375",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-3018c28d35e1eef664f2ffab",
        "anchorId": "anchor-2e4c03a15d3acd1d804e91a9",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 177,
          "endLine": 182,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "VersionResolution(\n            document=get_latest_version_for_root(\n                root_doc,\n                include_deleted=include_deleted,\n            ),\n        )",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-93fdecbcd742d5f8f0082c60",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 169,
          "endLine": 195
        },
        "sourceRevision": "ae4d06ea8444588b2ec1403b938a9ce41ed5e552713b65acd756ed6f839eea8f",
        "call": {
          "sourceCallId": "call-269b4af0a51d5e374ce1a294",
          "expression": "VersionResolution",
          "arguments": [
            {
              "expression": "get_latest_version_for_root(\n                root_doc,\n                include_deleted=include_deleted,\n            )",
              "sourceCallId": "call-77bf7b9a3e2f975a454a8316",
              "parameterName": "document"
            }
          ],
          "candidateIds": [
            "struct-69853106170513f930160de4"
          ],
          "resultNames": [],
          "resultBinding": "result-848f1216e2ab7f39"
        },
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 176,
              "endLine": 176
            },
            "anchorId": "anchor-6340156d3c7121160d1247d1",
            "text": "not version_param",
            "branch": "true",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 206,
              "endLine": 210
            },
            "sourceCallId": "call-52b0c18ef6069938221ad495",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1377,
              "endLine": 1381
            },
            "sourceCallId": "call-da3968f2ad4de57a86787375",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-20c15dd69c2ed702ea886739",
        "anchorId": "anchor-ebd67b5294dfeac7c656b641",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 178,
          "endLine": 181,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "get_latest_version_for_root(\n                root_doc,\n                include_deleted=include_deleted,\n            )",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-93fdecbcd742d5f8f0082c60",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 169,
          "endLine": 195
        },
        "sourceRevision": "ae4d06ea8444588b2ec1403b938a9ce41ed5e552713b65acd756ed6f839eea8f",
        "call": {
          "sourceCallId": "call-77bf7b9a3e2f975a454a8316",
          "expression": "get_latest_version_for_root",
          "arguments": [
            {
              "expression": "root_doc"
            },
            {
              "expression": "include_deleted",
              "parameterName": "include_deleted"
            }
          ],
          "candidateIds": [
            "struct-10ff580c76a7c53d792e0822"
          ],
          "resultNames": [],
          "resultBinding": "result-c4252239dd9174e6"
        },
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 176,
              "endLine": 176
            },
            "anchorId": "anchor-6340156d3c7121160d1247d1",
            "text": "not version_param",
            "branch": "true",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 206,
              "endLine": 210
            },
            "sourceCallId": "call-52b0c18ef6069938221ad495",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1377,
              "endLine": 1381
            },
            "sourceCallId": "call-da3968f2ad4de57a86787375",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-dd40e23d02e445535f1ec354",
        "anchorId": "anchor-6f8992a778e9717103709254",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 185,
          "endLine": 185,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "int(version_param)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-93fdecbcd742d5f8f0082c60",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 169,
          "endLine": 195
        },
        "sourceRevision": "ae4d06ea8444588b2ec1403b938a9ce41ed5e552713b65acd756ed6f839eea8f",
        "call": {
          "sourceCallId": "call-3fe877ded1b14bdf7d62274c",
          "expression": "int",
          "arguments": [
            {
              "expression": "version_param"
            }
          ],
          "candidateIds": [],
          "resultNames": [
            "version_id"
          ],
          "resultBinding": "version_id"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 206,
              "endLine": 210
            },
            "sourceCallId": "call-52b0c18ef6069938221ad495",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1377,
              "endLine": 1381
            },
            "sourceCallId": "call-da3968f2ad4de57a86787375",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-9c26a7b694c9f0e197ac3a61",
        "anchorId": "anchor-a0ae74b34f58b36657c17719",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 187,
          "endLine": 187,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "return VersionResolution(document=None, error=VersionResolutionError.INVALID)",
        "kind": "return-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-93fdecbcd742d5f8f0082c60",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 169,
          "endLine": 195
        },
        "sourceRevision": "ae4d06ea8444588b2ec1403b938a9ce41ed5e552713b65acd756ed6f839eea8f",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 206,
              "endLine": 210
            },
            "sourceCallId": "call-52b0c18ef6069938221ad495",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1377,
              "endLine": 1381
            },
            "sourceCallId": "call-da3968f2ad4de57a86787375",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-86f510dbd317058965648859",
        "anchorId": "anchor-0d55d0da7ddbb2d63b6bf9a2",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 187,
          "endLine": 187,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "VersionResolution(document=None, error=VersionResolutionError.INVALID)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-93fdecbcd742d5f8f0082c60",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 169,
          "endLine": 195
        },
        "sourceRevision": "ae4d06ea8444588b2ec1403b938a9ce41ed5e552713b65acd756ed6f839eea8f",
        "call": {
          "sourceCallId": "call-0038a4f136f9468a4cc8964f",
          "expression": "VersionResolution",
          "arguments": [
            {
              "expression": "None",
              "parameterName": "document",
              "literalKnown": true,
              "literalValue": null
            },
            {
              "expression": "VersionResolutionError.INVALID",
              "parameterName": "error"
            }
          ],
          "candidateIds": [
            "struct-69853106170513f930160de4"
          ],
          "resultNames": [],
          "resultBinding": "result-d154caeecd23066b"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 206,
              "endLine": 210
            },
            "sourceCallId": "call-52b0c18ef6069938221ad495",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1377,
              "endLine": 1381
            },
            "sourceCallId": "call-da3968f2ad4de57a86787375",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-aeaaf8bb42e8f8a9bfbb0dbb",
        "anchorId": "anchor-b061d3520e05bc3494961c4a",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 189,
          "endLine": 189,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "_document_manager(include_deleted=include_deleted)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-93fdecbcd742d5f8f0082c60",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 169,
          "endLine": 195
        },
        "sourceRevision": "ae4d06ea8444588b2ec1403b938a9ce41ed5e552713b65acd756ed6f839eea8f",
        "call": {
          "sourceCallId": "call-e7c4350f54ed9098f5fdaf16",
          "expression": "_document_manager",
          "arguments": [
            {
              "expression": "include_deleted",
              "parameterName": "include_deleted"
            }
          ],
          "candidateIds": [
            "struct-e227d7ee179daabbf744e8e9"
          ],
          "resultNames": [
            "manager"
          ],
          "resultBinding": "manager"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 206,
              "endLine": 210
            },
            "sourceCallId": "call-52b0c18ef6069938221ad495",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1377,
              "endLine": 1381
            },
            "sourceCallId": "call-da3968f2ad4de57a86787375",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-faf0f4bcb5a035c7ef842916",
        "anchorId": "anchor-cfa0f948153dc89a3a21624a",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 190,
          "endLine": 190,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "manager.only(\"id\", \"root_document_id\").filter(id=version_id)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-93fdecbcd742d5f8f0082c60",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 169,
          "endLine": 195
        },
        "sourceRevision": "ae4d06ea8444588b2ec1403b938a9ce41ed5e552713b65acd756ed6f839eea8f",
        "call": {
          "sourceCallId": "call-de4c1d375444a5acc6501837",
          "expression": "manager.only(\"id\", \"root_document_id\").filter",
          "receiver": "manager.only(\"id\", \"root_document_id\")",
          "arguments": [
            {
              "expression": "version_id",
              "parameterName": "id"
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-5c41515d694e4470"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 206,
              "endLine": 210
            },
            "sourceCallId": "call-52b0c18ef6069938221ad495",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1377,
              "endLine": 1381
            },
            "sourceCallId": "call-da3968f2ad4de57a86787375",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-c0fa8a3df85409d49f89389e",
        "anchorId": "anchor-d1749b83fb058f1efb9b4231",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 190,
          "endLine": 190,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "manager.only(\"id\", \"root_document_id\")",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-93fdecbcd742d5f8f0082c60",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 169,
          "endLine": 195
        },
        "sourceRevision": "ae4d06ea8444588b2ec1403b938a9ce41ed5e552713b65acd756ed6f839eea8f",
        "call": {
          "sourceCallId": "call-de4c1d375444a5acc6501837",
          "expression": "manager.only",
          "receiver": "manager",
          "arguments": [
            {
              "expression": "\"id\"",
              "literalKnown": true,
              "literalValue": "id"
            },
            {
              "expression": "\"root_document_id\"",
              "literalKnown": true,
              "literalValue": "root_document_id"
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-5c41515d694e4470"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 206,
              "endLine": 210
            },
            "sourceCallId": "call-52b0c18ef6069938221ad495",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1377,
              "endLine": 1381
            },
            "sourceCallId": "call-da3968f2ad4de57a86787375",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-db2d61b0089ab34c5e53dddc",
        "anchorId": "anchor-e5fe000a9a0a1fa94e64219c",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 190,
          "endLine": 190,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "manager.only(\"id\", \"root_document_id\").filter(id=version_id).first()",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-93fdecbcd742d5f8f0082c60",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 169,
          "endLine": 195
        },
        "sourceRevision": "ae4d06ea8444588b2ec1403b938a9ce41ed5e552713b65acd756ed6f839eea8f",
        "call": {
          "sourceCallId": "call-de4c1d375444a5acc6501837",
          "expression": "manager.only(\"id\", \"root_document_id\").filter(id=version_id).first",
          "receiver": "manager.only(\"id\", \"root_document_id\").filter(id=version_id)",
          "arguments": [],
          "candidateIds": [],
          "resultNames": [
            "candidate"
          ],
          "resultBinding": "candidate"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 206,
              "endLine": 210
            },
            "sourceCallId": "call-52b0c18ef6069938221ad495",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1377,
              "endLine": 1381
            },
            "sourceCallId": "call-da3968f2ad4de57a86787375",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-166b624bdb8227610d965083",
        "anchorId": "anchor-4fa42b5d44409db9774603f9",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 191,
          "endLine": 191,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "candidate is None",
        "kind": "branch-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-93fdecbcd742d5f8f0082c60",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 169,
          "endLine": 195
        },
        "sourceRevision": "ae4d06ea8444588b2ec1403b938a9ce41ed5e552713b65acd756ed6f839eea8f",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 206,
              "endLine": 210
            },
            "sourceCallId": "call-52b0c18ef6069938221ad495",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1377,
              "endLine": 1381
            },
            "sourceCallId": "call-da3968f2ad4de57a86787375",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-effbd7148251a2a7b73c4e9a",
        "anchorId": "anchor-ebf9a656f31a3aa50e2a7818",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 192,
          "endLine": 192,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "return VersionResolution(document=None, error=VersionResolutionError.NOT_FOUND)",
        "kind": "return-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-93fdecbcd742d5f8f0082c60",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 169,
          "endLine": 195
        },
        "sourceRevision": "ae4d06ea8444588b2ec1403b938a9ce41ed5e552713b65acd756ed6f839eea8f",
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 191,
              "endLine": 191
            },
            "anchorId": "anchor-4fa42b5d44409db9774603f9",
            "text": "candidate is None",
            "branch": "true",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 206,
              "endLine": 210
            },
            "sourceCallId": "call-52b0c18ef6069938221ad495",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1377,
              "endLine": 1381
            },
            "sourceCallId": "call-da3968f2ad4de57a86787375",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-456c045396aaa175d0d3d5dc",
        "anchorId": "anchor-3ad9215addb4c3a44bc12e1b",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 192,
          "endLine": 192,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "VersionResolution(document=None, error=VersionResolutionError.NOT_FOUND)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-93fdecbcd742d5f8f0082c60",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 169,
          "endLine": 195
        },
        "sourceRevision": "ae4d06ea8444588b2ec1403b938a9ce41ed5e552713b65acd756ed6f839eea8f",
        "call": {
          "sourceCallId": "call-b427b2af988791e43d2d8ac0",
          "expression": "VersionResolution",
          "arguments": [
            {
              "expression": "None",
              "parameterName": "document",
              "literalKnown": true,
              "literalValue": null
            },
            {
              "expression": "VersionResolutionError.NOT_FOUND",
              "parameterName": "error"
            }
          ],
          "candidateIds": [
            "struct-69853106170513f930160de4"
          ],
          "resultNames": [],
          "resultBinding": "result-80f17658b07c0fea"
        },
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 191,
              "endLine": 191
            },
            "anchorId": "anchor-4fa42b5d44409db9774603f9",
            "text": "candidate is None",
            "branch": "true",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 206,
              "endLine": 210
            },
            "sourceCallId": "call-52b0c18ef6069938221ad495",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1377,
              "endLine": 1381
            },
            "sourceCallId": "call-da3968f2ad4de57a86787375",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-9a53dcfe681376ee69f8ee07",
        "anchorId": "anchor-9d7585a021dc33a182fab97f",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 193,
          "endLine": 193,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "candidate.id != root_doc.id and candidate.root_document_id != root_doc.id",
        "kind": "branch-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-93fdecbcd742d5f8f0082c60",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 169,
          "endLine": 195
        },
        "sourceRevision": "ae4d06ea8444588b2ec1403b938a9ce41ed5e552713b65acd756ed6f839eea8f",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 206,
              "endLine": 210
            },
            "sourceCallId": "call-52b0c18ef6069938221ad495",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1377,
              "endLine": 1381
            },
            "sourceCallId": "call-da3968f2ad4de57a86787375",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-817deabfd6d2827699a10cb8",
        "anchorId": "anchor-8d8e56cb1eb4afe93af84f89",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 194,
          "endLine": 194,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "return VersionResolution(document=None, error=VersionResolutionError.NOT_FOUND)",
        "kind": "return-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-93fdecbcd742d5f8f0082c60",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 169,
          "endLine": 195
        },
        "sourceRevision": "ae4d06ea8444588b2ec1403b938a9ce41ed5e552713b65acd756ed6f839eea8f",
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 193,
              "endLine": 193
            },
            "anchorId": "anchor-9d7585a021dc33a182fab97f",
            "text": "candidate.id != root_doc.id and candidate.root_document_id != root_doc.id",
            "branch": "true",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 206,
              "endLine": 210
            },
            "sourceCallId": "call-52b0c18ef6069938221ad495",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1377,
              "endLine": 1381
            },
            "sourceCallId": "call-da3968f2ad4de57a86787375",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-b14b45fff0e523d89665a120",
        "anchorId": "anchor-629f5c8c4b63a81e175fb3d9",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 194,
          "endLine": 194,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "VersionResolution(document=None, error=VersionResolutionError.NOT_FOUND)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-93fdecbcd742d5f8f0082c60",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 169,
          "endLine": 195
        },
        "sourceRevision": "ae4d06ea8444588b2ec1403b938a9ce41ed5e552713b65acd756ed6f839eea8f",
        "call": {
          "sourceCallId": "call-adee74c2401d85e5a4b6d2be",
          "expression": "VersionResolution",
          "arguments": [
            {
              "expression": "None",
              "parameterName": "document",
              "literalKnown": true,
              "literalValue": null
            },
            {
              "expression": "VersionResolutionError.NOT_FOUND",
              "parameterName": "error"
            }
          ],
          "candidateIds": [
            "struct-69853106170513f930160de4"
          ],
          "resultNames": [],
          "resultBinding": "result-a180526120c0cdeb"
        },
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 193,
              "endLine": 193
            },
            "anchorId": "anchor-9d7585a021dc33a182fab97f",
            "text": "candidate.id != root_doc.id and candidate.root_document_id != root_doc.id",
            "branch": "true",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 206,
              "endLine": 210
            },
            "sourceCallId": "call-52b0c18ef6069938221ad495",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1377,
              "endLine": 1381
            },
            "sourceCallId": "call-da3968f2ad4de57a86787375",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-8e453de5c95dddf7a7f60ab6",
        "anchorId": "anchor-cc94feb5d1c4a1c307ce0f08",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 195,
          "endLine": 195,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "return VersionResolution(document=candidate)",
        "kind": "return-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-93fdecbcd742d5f8f0082c60",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 169,
          "endLine": 195
        },
        "sourceRevision": "ae4d06ea8444588b2ec1403b938a9ce41ed5e552713b65acd756ed6f839eea8f",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 206,
              "endLine": 210
            },
            "sourceCallId": "call-52b0c18ef6069938221ad495",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1377,
              "endLine": 1381
            },
            "sourceCallId": "call-da3968f2ad4de57a86787375",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-1b85a8ee3bb29879a02da058",
        "anchorId": "anchor-6aceba74ced4e5ec5059e2dc",
        "source": {
          "path": "src/documents/versioning.py",
          "startLine": 195,
          "endLine": 195,
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
        },
        "text": "VersionResolution(document=candidate)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-93fdecbcd742d5f8f0082c60",
          "path": "src/documents/versioning.py",
          "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
          "startLine": 169,
          "endLine": 195
        },
        "sourceRevision": "ae4d06ea8444588b2ec1403b938a9ce41ed5e552713b65acd756ed6f839eea8f",
        "call": {
          "sourceCallId": "call-89704b8808acf40087ae9c39",
          "expression": "VersionResolution",
          "arguments": [
            {
              "expression": "candidate",
              "parameterName": "document"
            }
          ],
          "candidateIds": [
            "struct-69853106170513f930160de4"
          ],
          "resultNames": [],
          "resultBinding": "result-4ea47693027e8209"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/versioning.py",
              "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766",
              "startLine": 206,
              "endLine": 210
            },
            "sourceCallId": "call-52b0c18ef6069938221ad495",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1377,
              "endLine": 1381
            },
            "sourceCallId": "call-da3968f2ad4de57a86787375",
            "candidateIds": [
              "struct-93fdecbcd742d5f8f0082c60"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-315b3897688fdd18937348ad",
        "anchorId": "anchor-e6ffc98f42eed13aec7888a7",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1370,
          "endLine": 1373,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "return (\n            \"original\" in request.query_params\n            and request.query_params[\"original\"] == \"true\"\n        )",
        "kind": "return-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-8363b0b6a86b25273c205577",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1369,
          "endLine": 1373
        },
        "sourceRevision": "77ba11b3167e72091ef88cbcec3c0898311ada727a51315d2e7313f1dc20e124",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1444,
              "endLine": 1444
            },
            "sourceCallId": "call-cc03ccc8ef4c67dbf98fa7de",
            "candidateIds": [
              "struct-8363b0b6a86b25273c205577"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1802,
              "endLine": 1802
            },
            "sourceCallId": "call-b699da2dbca83b000b53160a",
            "candidateIds": [
              "struct-8363b0b6a86b25273c205577"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-4709097cdd7ae4cc8091c4ab",
        "anchorId": "anchor-acdf3337eb976b6310afdf9b",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1376,
          "endLine": 1376,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "get_request_version_param(request)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-df88a902db65187c54f36c79",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1375,
          "endLine": 1386
        },
        "sourceRevision": "065a88267d95e482da6bac807e43c878f36e2d61589bd4b2ed8babf5acb21f27",
        "call": {
          "sourceCallId": "call-849c9bed36a52d17d377b5a5",
          "expression": "get_request_version_param",
          "arguments": [
            {
              "expression": "request"
            }
          ],
          "candidateIds": [
            "struct-810e51903be781c2063bfee4"
          ],
          "resultNames": [],
          "resultBinding": "result-36e6b62f7373b8ed"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1279,
              "endLine": 1279
            },
            "sourceCallId": "call-c99b54d7641d35e205067f70",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1287,
              "endLine": 1287
            },
            "sourceCallId": "call-80ae40b214fd9a54403df091",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1399,
              "endLine": 1399
            },
            "sourceCallId": "call-a96313b6b0e856f9ff116625",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-734da2050148f1662cef491d",
        "anchorId": "anchor-4045770c0434970a340f169e",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1377,
          "endLine": 1381,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "resolve_requested_version_for_root(\n            root_doc,\n            request,\n            include_deleted=version_requested,\n        )",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-df88a902db65187c54f36c79",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1375,
          "endLine": 1386
        },
        "sourceRevision": "065a88267d95e482da6bac807e43c878f36e2d61589bd4b2ed8babf5acb21f27",
        "call": {
          "sourceCallId": "call-da3968f2ad4de57a86787375",
          "expression": "resolve_requested_version_for_root",
          "arguments": [
            {
              "expression": "root_doc"
            },
            {
              "expression": "request"
            },
            {
              "expression": "version_requested",
              "parameterName": "include_deleted"
            }
          ],
          "candidateIds": [
            "struct-93fdecbcd742d5f8f0082c60"
          ],
          "resultNames": [
            "resolution"
          ],
          "resultBinding": "resolution"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1279,
              "endLine": 1279
            },
            "sourceCallId": "call-c99b54d7641d35e205067f70",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1287,
              "endLine": 1287
            },
            "sourceCallId": "call-80ae40b214fd9a54403df091",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1399,
              "endLine": 1399
            },
            "sourceCallId": "call-a96313b6b0e856f9ff116625",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-83a18a7c51184ce0b3d43865",
        "anchorId": "anchor-e7ee8fa08c0add3dbdcc4f71",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1382,
          "endLine": 1382,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "resolution.error == VersionResolutionError.INVALID",
        "kind": "branch-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-df88a902db65187c54f36c79",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1375,
          "endLine": 1386
        },
        "sourceRevision": "065a88267d95e482da6bac807e43c878f36e2d61589bd4b2ed8babf5acb21f27",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1279,
              "endLine": 1279
            },
            "sourceCallId": "call-c99b54d7641d35e205067f70",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1287,
              "endLine": 1287
            },
            "sourceCallId": "call-80ae40b214fd9a54403df091",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1399,
              "endLine": 1399
            },
            "sourceCallId": "call-a96313b6b0e856f9ff116625",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-5bb86404b9568ce0f707eb31",
        "anchorId": "anchor-8a9181c53be683e242ea8cc6",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1383,
          "endLine": 1383,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "raise NotFound(\"Invalid version parameter\")",
        "kind": "error-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-df88a902db65187c54f36c79",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1375,
          "endLine": 1386
        },
        "sourceRevision": "065a88267d95e482da6bac807e43c878f36e2d61589bd4b2ed8babf5acb21f27",
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1382,
              "endLine": 1382
            },
            "anchorId": "anchor-e7ee8fa08c0add3dbdcc4f71",
            "text": "resolution.error == VersionResolutionError.INVALID",
            "branch": "true",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1279,
              "endLine": 1279
            },
            "sourceCallId": "call-c99b54d7641d35e205067f70",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1287,
              "endLine": 1287
            },
            "sourceCallId": "call-80ae40b214fd9a54403df091",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1399,
              "endLine": 1399
            },
            "sourceCallId": "call-a96313b6b0e856f9ff116625",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-aeb89b34abf1ed6b1e68c9ad",
        "anchorId": "anchor-6f579b53d706374fbbaf5749",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1383,
          "endLine": 1383,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "NotFound(\"Invalid version parameter\")",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-df88a902db65187c54f36c79",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1375,
          "endLine": 1386
        },
        "sourceRevision": "065a88267d95e482da6bac807e43c878f36e2d61589bd4b2ed8babf5acb21f27",
        "call": {
          "sourceCallId": "call-47bb309948904667576600a7",
          "expression": "NotFound",
          "arguments": [
            {
              "expression": "\"Invalid version parameter\"",
              "literalKnown": true,
              "literalValue": "Invalid version parameter"
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-f62f1d2d03c4df6a"
        },
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1382,
              "endLine": 1382
            },
            "anchorId": "anchor-e7ee8fa08c0add3dbdcc4f71",
            "text": "resolution.error == VersionResolutionError.INVALID",
            "branch": "true",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1279,
              "endLine": 1279
            },
            "sourceCallId": "call-c99b54d7641d35e205067f70",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1287,
              "endLine": 1287
            },
            "sourceCallId": "call-80ae40b214fd9a54403df091",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1399,
              "endLine": 1399
            },
            "sourceCallId": "call-a96313b6b0e856f9ff116625",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-05e5c01d0451318c1df9a2da",
        "anchorId": "anchor-4a978c4dd33cc04e4ab5d3dc",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1384,
          "endLine": 1384,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "resolution.document is None",
        "kind": "branch-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-df88a902db65187c54f36c79",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1375,
          "endLine": 1386
        },
        "sourceRevision": "065a88267d95e482da6bac807e43c878f36e2d61589bd4b2ed8babf5acb21f27",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1279,
              "endLine": 1279
            },
            "sourceCallId": "call-c99b54d7641d35e205067f70",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1287,
              "endLine": 1287
            },
            "sourceCallId": "call-80ae40b214fd9a54403df091",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1399,
              "endLine": 1399
            },
            "sourceCallId": "call-a96313b6b0e856f9ff116625",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-f70eadcba42172c0ce634515",
        "anchorId": "anchor-aad5700679863ee11e749e0d",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1385,
          "endLine": 1385,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "raise Http404",
        "kind": "error-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-df88a902db65187c54f36c79",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1375,
          "endLine": 1386
        },
        "sourceRevision": "065a88267d95e482da6bac807e43c878f36e2d61589bd4b2ed8babf5acb21f27",
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1384,
              "endLine": 1384
            },
            "anchorId": "anchor-4a978c4dd33cc04e4ab5d3dc",
            "text": "resolution.document is None",
            "branch": "true",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1279,
              "endLine": 1279
            },
            "sourceCallId": "call-c99b54d7641d35e205067f70",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1287,
              "endLine": 1287
            },
            "sourceCallId": "call-80ae40b214fd9a54403df091",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1399,
              "endLine": 1399
            },
            "sourceCallId": "call-a96313b6b0e856f9ff116625",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-b9d4db4d9110ed10f7f95ea3",
        "anchorId": "anchor-9afa832c72dc3f472fe903d7",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1386,
          "endLine": 1386,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "return resolution.document",
        "kind": "return-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-df88a902db65187c54f36c79",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1375,
          "endLine": 1386
        },
        "sourceRevision": "065a88267d95e482da6bac807e43c878f36e2d61589bd4b2ed8babf5acb21f27",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1279,
              "endLine": 1279
            },
            "sourceCallId": "call-c99b54d7641d35e205067f70",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1287,
              "endLine": 1287
            },
            "sourceCallId": "call-80ae40b214fd9a54403df091",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1399,
              "endLine": 1399
            },
            "sourceCallId": "call-a96313b6b0e856f9ff116625",
            "candidateIds": [
              "struct-df88a902db65187c54f36c79"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-916f10a06d73d8aa20078aea",
        "anchorId": "anchor-7b7688faae079b557c3d3f6c",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1394,
          "endLine": 1397,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "(\n            request_doc.root_document_id is not None\n            and get_request_version_param(request) is None\n        )",
        "kind": "branch-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-c324d0c7523b878776417593",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1388,
          "endLine": 1399
        },
        "sourceRevision": "8dc802eb15680be55d11f13071c600eb91ab001efd11511efc654a983dde6f74",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1437,
              "endLine": 1441
            },
            "sourceCallId": "call-878a7aff26af5b893259049f",
            "candidateIds": [
              "struct-c324d0c7523b878776417593"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1487,
              "endLine": 1491
            },
            "sourceCallId": "call-21f648c92c2a24b10f755332",
            "candidateIds": [
              "struct-c324d0c7523b878776417593"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1794,
              "endLine": 1798
            },
            "sourceCallId": "call-0781fcdba9138db9a9f061e6",
            "candidateIds": [
              "struct-c324d0c7523b878776417593"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1823,
              "endLine": 1827
            },
            "sourceCallId": "call-47049391336c0d71dbcb88d2",
            "candidateIds": [
              "struct-c324d0c7523b878776417593"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-eb52e13b662108d8d0a876d3",
        "anchorId": "anchor-66953a7037f6e1fcfe413149",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1396,
          "endLine": 1396,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "get_request_version_param(request)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-c324d0c7523b878776417593",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1388,
          "endLine": 1399
        },
        "sourceRevision": "8dc802eb15680be55d11f13071c600eb91ab001efd11511efc654a983dde6f74",
        "call": {
          "sourceCallId": "call-762faef438df4c815df72179",
          "expression": "get_request_version_param",
          "arguments": [
            {
              "expression": "request"
            }
          ],
          "candidateIds": [
            "struct-810e51903be781c2063bfee4"
          ],
          "resultNames": [],
          "resultBinding": "result-8c50d36ce8274c97"
        },
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1395,
              "endLine": 1396
            },
            "anchorId": "anchor-90a70d83c1f0f382a2fe8496",
            "text": "request_doc.root_document_id is not None\n            and get_request_version_param(request) is None",
            "branch": "and-right",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1437,
              "endLine": 1441
            },
            "sourceCallId": "call-878a7aff26af5b893259049f",
            "candidateIds": [
              "struct-c324d0c7523b878776417593"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1487,
              "endLine": 1491
            },
            "sourceCallId": "call-21f648c92c2a24b10f755332",
            "candidateIds": [
              "struct-c324d0c7523b878776417593"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1794,
              "endLine": 1798
            },
            "sourceCallId": "call-0781fcdba9138db9a9f061e6",
            "candidateIds": [
              "struct-c324d0c7523b878776417593"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1823,
              "endLine": 1827
            },
            "sourceCallId": "call-47049391336c0d71dbcb88d2",
            "candidateIds": [
              "struct-c324d0c7523b878776417593"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-3375afc7bf04b233f4be6a02",
        "anchorId": "anchor-f0723de2ba5eb016fdcc1ea8",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1398,
          "endLine": 1398,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "return request_doc",
        "kind": "return-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-c324d0c7523b878776417593",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1388,
          "endLine": 1399
        },
        "sourceRevision": "8dc802eb15680be55d11f13071c600eb91ab001efd11511efc654a983dde6f74",
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1394,
              "endLine": 1397
            },
            "anchorId": "anchor-7b7688faae079b557c3d3f6c",
            "text": "(\n            request_doc.root_document_id is not None\n            and get_request_version_param(request) is None\n        )",
            "branch": "true",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1437,
              "endLine": 1441
            },
            "sourceCallId": "call-878a7aff26af5b893259049f",
            "candidateIds": [
              "struct-c324d0c7523b878776417593"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1487,
              "endLine": 1491
            },
            "sourceCallId": "call-21f648c92c2a24b10f755332",
            "candidateIds": [
              "struct-c324d0c7523b878776417593"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1794,
              "endLine": 1798
            },
            "sourceCallId": "call-0781fcdba9138db9a9f061e6",
            "candidateIds": [
              "struct-c324d0c7523b878776417593"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1823,
              "endLine": 1827
            },
            "sourceCallId": "call-47049391336c0d71dbcb88d2",
            "candidateIds": [
              "struct-c324d0c7523b878776417593"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-18c1d1e50b08771ba08847d1",
        "anchorId": "anchor-610a81e37c9e480d1a054e6b",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1399,
          "endLine": 1399,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "return self._resolve_file_doc(root_doc, request)",
        "kind": "return-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-c324d0c7523b878776417593",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1388,
          "endLine": 1399
        },
        "sourceRevision": "8dc802eb15680be55d11f13071c600eb91ab001efd11511efc654a983dde6f74",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1437,
              "endLine": 1441
            },
            "sourceCallId": "call-878a7aff26af5b893259049f",
            "candidateIds": [
              "struct-c324d0c7523b878776417593"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1487,
              "endLine": 1491
            },
            "sourceCallId": "call-21f648c92c2a24b10f755332",
            "candidateIds": [
              "struct-c324d0c7523b878776417593"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1794,
              "endLine": 1798
            },
            "sourceCallId": "call-0781fcdba9138db9a9f061e6",
            "candidateIds": [
              "struct-c324d0c7523b878776417593"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1823,
              "endLine": 1827
            },
            "sourceCallId": "call-47049391336c0d71dbcb88d2",
            "candidateIds": [
              "struct-c324d0c7523b878776417593"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-12ddd92c37ddedeabd72c09e",
        "anchorId": "anchor-060fb3d1a8148d34b512b6c9",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1399,
          "endLine": 1399,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "self._resolve_file_doc(root_doc, request)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-c324d0c7523b878776417593",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1388,
          "endLine": 1399
        },
        "sourceRevision": "8dc802eb15680be55d11f13071c600eb91ab001efd11511efc654a983dde6f74",
        "call": {
          "sourceCallId": "call-a96313b6b0e856f9ff116625",
          "expression": "self._resolve_file_doc",
          "receiver": "self",
          "receiverClass": "documents.views.DocumentViewSet",
          "arguments": [
            {
              "expression": "root_doc"
            },
            {
              "expression": "request"
            }
          ],
          "candidateIds": [
            "struct-df88a902db65187c54f36c79"
          ],
          "resultNames": [],
          "resultBinding": "result-4cfbd0973361d8bf"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1437,
              "endLine": 1441
            },
            "sourceCallId": "call-878a7aff26af5b893259049f",
            "candidateIds": [
              "struct-c324d0c7523b878776417593"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1487,
              "endLine": 1491
            },
            "sourceCallId": "call-21f648c92c2a24b10f755332",
            "candidateIds": [
              "struct-c324d0c7523b878776417593"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1794,
              "endLine": 1798
            },
            "sourceCallId": "call-0781fcdba9138db9a9f061e6",
            "candidateIds": [
              "struct-c324d0c7523b878776417593"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1823,
              "endLine": 1827
            },
            "sourceCallId": "call-47049391336c0d71dbcb88d2",
            "candidateIds": [
              "struct-c324d0c7523b878776417593"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-2bfdba999beeb001d81b63fb",
        "anchorId": "anchor-93e63ee0ab54d203569453b8",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1410,
          "endLine": 1413,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "manager.select_related(\n                \"owner\",\n                \"root_document\",\n            )",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-4a9672f6253534ddaf14b54e",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1401,
          "endLine": 1427
        },
        "sourceRevision": "5a1ebd6ed96699ac321492480e89635fd7bf12753fcde4dacfac447b6c1f3093",
        "call": {
          "sourceCallId": "call-89cabef1023f54fa1f77ef22",
          "expression": "manager.select_related",
          "receiver": "manager",
          "arguments": [
            {
              "expression": "\"owner\"",
              "literalKnown": true,
              "literalValue": "owner"
            },
            {
              "expression": "\"root_document\"",
              "literalKnown": true,
              "literalValue": "root_document"
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-42f3f10ec2eb4950"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1430,
              "endLine": 1434
            },
            "sourceCallId": "call-82799ef45b1e563164b85820",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1481,
              "endLine": 1481
            },
            "sourceCallId": "call-fc96adf865ab0ee01ce2a021",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1789,
              "endLine": 1789
            },
            "sourceCallId": "call-15c7b53b5e33cad1219856a2",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1818,
              "endLine": 1818
            },
            "sourceCallId": "call-ffe7cf5b0e4dcee6bd537d4e",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-1da58c1ab50ff4100816e96b",
        "anchorId": "anchor-b29d6f9b96996d0b50cdd9b4",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1410,
          "endLine": 1413,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "manager.select_related(\n                \"owner\",\n                \"root_document\",\n            ).get(id=pk)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-4a9672f6253534ddaf14b54e",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1401,
          "endLine": 1427
        },
        "sourceRevision": "5a1ebd6ed96699ac321492480e89635fd7bf12753fcde4dacfac447b6c1f3093",
        "call": {
          "sourceCallId": "call-89cabef1023f54fa1f77ef22",
          "expression": "manager.select_related(\n                \"owner\",\n                \"root_document\",\n            ).get",
          "receiver": "manager.select_related(\n                \"owner\",\n                \"root_document\",\n            )",
          "arguments": [
            {
              "expression": "pk",
              "parameterName": "id"
            }
          ],
          "candidateIds": [],
          "resultNames": [
            "request_doc"
          ],
          "resultBinding": "request_doc"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1430,
              "endLine": 1434
            },
            "sourceCallId": "call-82799ef45b1e563164b85820",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1481,
              "endLine": 1481
            },
            "sourceCallId": "call-fc96adf865ab0ee01ce2a021",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1789,
              "endLine": 1789
            },
            "sourceCallId": "call-15c7b53b5e33cad1219856a2",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1818,
              "endLine": 1818
            },
            "sourceCallId": "call-ffe7cf5b0e4dcee6bd537d4e",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-8ed0ef7c0af5c5eb787a7aa4",
        "anchorId": "anchor-ec7b89d3e1272a881ba9e466",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1415,
          "endLine": 1415,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "raise Http404",
        "kind": "error-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-4a9672f6253534ddaf14b54e",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1401,
          "endLine": 1427
        },
        "sourceRevision": "5a1ebd6ed96699ac321492480e89635fd7bf12753fcde4dacfac447b6c1f3093",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1430,
              "endLine": 1434
            },
            "sourceCallId": "call-82799ef45b1e563164b85820",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1481,
              "endLine": 1481
            },
            "sourceCallId": "call-fc96adf865ab0ee01ce2a021",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1789,
              "endLine": 1789
            },
            "sourceCallId": "call-15c7b53b5e33cad1219856a2",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1818,
              "endLine": 1818
            },
            "sourceCallId": "call-ffe7cf5b0e4dcee6bd537d4e",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-a82d0026ee94ec8bd455e686",
        "anchorId": "anchor-b067fc2b185d93a41b3e20a2",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1417,
          "endLine": 1420,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "get_root_document(\n            request_doc,\n            include_deleted=include_deleted,\n        )",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-4a9672f6253534ddaf14b54e",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1401,
          "endLine": 1427
        },
        "sourceRevision": "5a1ebd6ed96699ac321492480e89635fd7bf12753fcde4dacfac447b6c1f3093",
        "call": {
          "sourceCallId": "call-1b6611fb1500ce49654386e3",
          "expression": "get_root_document",
          "arguments": [
            {
              "expression": "request_doc"
            },
            {
              "expression": "include_deleted",
              "parameterName": "include_deleted"
            }
          ],
          "candidateIds": [
            "struct-7ab1297ea3f05dc30ca55b3d"
          ],
          "resultNames": [
            "root_doc"
          ],
          "resultBinding": "root_doc"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1430,
              "endLine": 1434
            },
            "sourceCallId": "call-82799ef45b1e563164b85820",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1481,
              "endLine": 1481
            },
            "sourceCallId": "call-fc96adf865ab0ee01ce2a021",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1789,
              "endLine": 1789
            },
            "sourceCallId": "call-15c7b53b5e33cad1219856a2",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1818,
              "endLine": 1818
            },
            "sourceCallId": "call-ffe7cf5b0e4dcee6bd537d4e",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-1dc49a4d6cdc61a6aae46ea8",
        "anchorId": "anchor-9c8aea5c5131da5671dec309",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1421,
          "endLine": 1425,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "request.user is not None and not has_perms_owner_aware(\n            request.user,\n            \"view_document\",\n            root_doc,\n        )",
        "kind": "branch-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-4a9672f6253534ddaf14b54e",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1401,
          "endLine": 1427
        },
        "sourceRevision": "5a1ebd6ed96699ac321492480e89635fd7bf12753fcde4dacfac447b6c1f3093",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1430,
              "endLine": 1434
            },
            "sourceCallId": "call-82799ef45b1e563164b85820",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1481,
              "endLine": 1481
            },
            "sourceCallId": "call-fc96adf865ab0ee01ce2a021",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1789,
              "endLine": 1789
            },
            "sourceCallId": "call-15c7b53b5e33cad1219856a2",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1818,
              "endLine": 1818
            },
            "sourceCallId": "call-ffe7cf5b0e4dcee6bd537d4e",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-b3c130de9b77fc3b45821324",
        "anchorId": "anchor-6ef2df3b93be385615f2aa79",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1421,
          "endLine": 1425,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "has_perms_owner_aware(\n            request.user,\n            \"view_document\",\n            root_doc,\n        )",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-4a9672f6253534ddaf14b54e",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1401,
          "endLine": 1427
        },
        "sourceRevision": "5a1ebd6ed96699ac321492480e89635fd7bf12753fcde4dacfac447b6c1f3093",
        "call": {
          "sourceCallId": "call-fe1fd3dd50fbb4ce08f46325",
          "expression": "has_perms_owner_aware",
          "arguments": [
            {
              "expression": "request.user"
            },
            {
              "expression": "\"view_document\"",
              "literalKnown": true,
              "literalValue": "view_document"
            },
            {
              "expression": "root_doc"
            }
          ],
          "candidateIds": [
            "struct-0c8bed3900304fcee9a1c0b6"
          ],
          "resultNames": [],
          "resultBinding": "result-afe818cd834c6632"
        },
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1421,
              "endLine": 1425
            },
            "anchorId": "anchor-41fcfe3c300d4aeab97a93ba",
            "text": "request.user is not None and not has_perms_owner_aware(\n            request.user,\n            \"view_document\",\n            root_doc,\n        )",
            "branch": "and-right",
            "stepIds": [
              "actor_present"
            ]
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1430,
              "endLine": 1434
            },
            "sourceCallId": "call-82799ef45b1e563164b85820",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1481,
              "endLine": 1481
            },
            "sourceCallId": "call-fc96adf865ab0ee01ce2a021",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1789,
              "endLine": 1789
            },
            "sourceCallId": "call-15c7b53b5e33cad1219856a2",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1818,
              "endLine": 1818
            },
            "sourceCallId": "call-ffe7cf5b0e4dcee6bd537d4e",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-c6b91078a5251ec6048f8120",
        "anchorId": "anchor-7ee48e34c178a1302448355f",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1426,
          "endLine": 1426,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "return HttpResponseForbidden(\"Insufficient permissions\")",
        "kind": "return-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-4a9672f6253534ddaf14b54e",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1401,
          "endLine": 1427
        },
        "sourceRevision": "5a1ebd6ed96699ac321492480e89635fd7bf12753fcde4dacfac447b6c1f3093",
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1421,
              "endLine": 1425
            },
            "anchorId": "anchor-9c8aea5c5131da5671dec309",
            "text": "request.user is not None and not has_perms_owner_aware(\n            request.user,\n            \"view_document\",\n            root_doc,\n        )",
            "branch": "true",
            "stepIds": [
              "actor_present"
            ]
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1430,
              "endLine": 1434
            },
            "sourceCallId": "call-82799ef45b1e563164b85820",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1481,
              "endLine": 1481
            },
            "sourceCallId": "call-fc96adf865ab0ee01ce2a021",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1789,
              "endLine": 1789
            },
            "sourceCallId": "call-15c7b53b5e33cad1219856a2",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1818,
              "endLine": 1818
            },
            "sourceCallId": "call-ffe7cf5b0e4dcee6bd537d4e",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-6bd2538eed7fd615d5b616d8",
        "anchorId": "anchor-7e93594c0bc3ce08eeee4623",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1426,
          "endLine": 1426,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "HttpResponseForbidden(\"Insufficient permissions\")",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-4a9672f6253534ddaf14b54e",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1401,
          "endLine": 1427
        },
        "sourceRevision": "5a1ebd6ed96699ac321492480e89635fd7bf12753fcde4dacfac447b6c1f3093",
        "call": {
          "sourceCallId": "call-c55aff397c665c6d79396905",
          "expression": "HttpResponseForbidden",
          "arguments": [
            {
              "expression": "\"Insufficient permissions\"",
              "literalKnown": true,
              "literalValue": "Insufficient permissions"
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-6efa09c412868063"
        },
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1421,
              "endLine": 1425
            },
            "anchorId": "anchor-9c8aea5c5131da5671dec309",
            "text": "request.user is not None and not has_perms_owner_aware(\n            request.user,\n            \"view_document\",\n            root_doc,\n        )",
            "branch": "true",
            "stepIds": [
              "actor_present"
            ]
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1430,
              "endLine": 1434
            },
            "sourceCallId": "call-82799ef45b1e563164b85820",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1481,
              "endLine": 1481
            },
            "sourceCallId": "call-fc96adf865ab0ee01ce2a021",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1789,
              "endLine": 1789
            },
            "sourceCallId": "call-15c7b53b5e33cad1219856a2",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1818,
              "endLine": 1818
            },
            "sourceCallId": "call-ffe7cf5b0e4dcee6bd537d4e",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-4df0f79cfd5481fe2c889546",
        "anchorId": "anchor-7b2e3f1d2d0973d7613ba7bb",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1427,
          "endLine": 1427,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "return ResolvedRequestDocs(request_doc=request_doc, root_doc=root_doc)",
        "kind": "return-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-4a9672f6253534ddaf14b54e",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1401,
          "endLine": 1427
        },
        "sourceRevision": "5a1ebd6ed96699ac321492480e89635fd7bf12753fcde4dacfac447b6c1f3093",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1430,
              "endLine": 1434
            },
            "sourceCallId": "call-82799ef45b1e563164b85820",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1481,
              "endLine": 1481
            },
            "sourceCallId": "call-fc96adf865ab0ee01ce2a021",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1789,
              "endLine": 1789
            },
            "sourceCallId": "call-15c7b53b5e33cad1219856a2",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1818,
              "endLine": 1818
            },
            "sourceCallId": "call-ffe7cf5b0e4dcee6bd537d4e",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-7ad63b0ec995ba5a58e02e65",
        "anchorId": "anchor-79f61fe12c5ac68f68076ce0",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1427,
          "endLine": 1427,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "ResolvedRequestDocs(request_doc=request_doc, root_doc=root_doc)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-4a9672f6253534ddaf14b54e",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1401,
          "endLine": 1427
        },
        "sourceRevision": "5a1ebd6ed96699ac321492480e89635fd7bf12753fcde4dacfac447b6c1f3093",
        "call": {
          "sourceCallId": "call-f8827c59362522708140a952",
          "expression": "ResolvedRequestDocs",
          "arguments": [
            {
              "expression": "request_doc",
              "parameterName": "request_doc"
            },
            {
              "expression": "root_doc",
              "parameterName": "root_doc"
            }
          ],
          "candidateIds": [
            "struct-1adbbb5232715656b83b3e3f"
          ],
          "resultNames": [],
          "resultBinding": "result-5844bde31396c8bc"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1430,
              "endLine": 1434
            },
            "sourceCallId": "call-82799ef45b1e563164b85820",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1481,
              "endLine": 1481
            },
            "sourceCallId": "call-fc96adf865ab0ee01ce2a021",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1789,
              "endLine": 1789
            },
            "sourceCallId": "call-15c7b53b5e33cad1219856a2",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1818,
              "endLine": 1818
            },
            "sourceCallId": "call-ffe7cf5b0e4dcee6bd537d4e",
            "candidateIds": [
              "struct-4a9672f6253534ddaf14b54e"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-45b0e22c7a0070d6364c9df6",
        "anchorId": "anchor-8c381d46def5890f94e11a98",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1430,
          "endLine": 1434,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "self._resolve_request_and_root_doc(\n            pk,\n            request,\n            include_deleted=True,\n        )",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-c1a6bd6945975b47fbb4b98c",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1429,
          "endLine": 1448
        },
        "sourceRevision": "efcea721f8eac86db5f605ad02af7f9f0c742f1549233715baa43c31601e365a",
        "call": {
          "sourceCallId": "call-82799ef45b1e563164b85820",
          "expression": "self._resolve_request_and_root_doc",
          "receiver": "self",
          "receiverClass": "documents.views.DocumentViewSet",
          "arguments": [
            {
              "expression": "pk"
            },
            {
              "expression": "request"
            },
            {
              "expression": "True",
              "parameterName": "include_deleted",
              "literalKnown": true,
              "literalValue": true
            }
          ],
          "candidateIds": [
            "struct-4a9672f6253534ddaf14b54e"
          ],
          "resultNames": [
            "resolved"
          ],
          "resultBinding": "resolved"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1837,
              "endLine": 1837
            },
            "sourceCallId": "call-474c747edb2d44ff9dc93ddb",
            "candidateIds": [
              "struct-c1a6bd6945975b47fbb4b98c"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-b83a17dffaa456280da23e2e",
        "anchorId": "anchor-4ce0c5e45e7c40a7a13776d0",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1435,
          "endLine": 1435,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "isinstance(resolved, HttpResponseForbidden)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-c1a6bd6945975b47fbb4b98c",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1429,
          "endLine": 1448
        },
        "sourceRevision": "efcea721f8eac86db5f605ad02af7f9f0c742f1549233715baa43c31601e365a",
        "call": {
          "sourceCallId": "call-c6cfc30fa5a80bb3428ee22c",
          "expression": "isinstance",
          "arguments": [
            {
              "expression": "resolved"
            },
            {
              "expression": "HttpResponseForbidden"
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-02fa0b3c2dc5a777"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1837,
              "endLine": 1837
            },
            "sourceCallId": "call-474c747edb2d44ff9dc93ddb",
            "candidateIds": [
              "struct-c1a6bd6945975b47fbb4b98c"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-2d958c94f976fd06e50c5f38",
        "anchorId": "anchor-ca4ab2d0932442369e3eadee",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1435,
          "endLine": 1435,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "isinstance(resolved, HttpResponseForbidden)",
        "kind": "branch-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-c1a6bd6945975b47fbb4b98c",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1429,
          "endLine": 1448
        },
        "sourceRevision": "efcea721f8eac86db5f605ad02af7f9f0c742f1549233715baa43c31601e365a",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1837,
              "endLine": 1837
            },
            "sourceCallId": "call-474c747edb2d44ff9dc93ddb",
            "candidateIds": [
              "struct-c1a6bd6945975b47fbb4b98c"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-b8a11b5f3ebb1cba0075c44f",
        "anchorId": "anchor-051aa0c18d787b2d04ad74cd",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1436,
          "endLine": 1436,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "return resolved",
        "kind": "return-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-c1a6bd6945975b47fbb4b98c",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1429,
          "endLine": 1448
        },
        "sourceRevision": "efcea721f8eac86db5f605ad02af7f9f0c742f1549233715baa43c31601e365a",
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1435,
              "endLine": 1435
            },
            "anchorId": "anchor-ca4ab2d0932442369e3eadee",
            "text": "isinstance(resolved, HttpResponseForbidden)",
            "branch": "true",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1837,
              "endLine": 1837
            },
            "sourceCallId": "call-474c747edb2d44ff9dc93ddb",
            "candidateIds": [
              "struct-c1a6bd6945975b47fbb4b98c"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-5c5889570a6193d477900f7c",
        "anchorId": "anchor-22ff90ff144b3a72469c33d8",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1437,
          "endLine": 1441,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "self._get_effective_file_doc(\n            resolved.request_doc,\n            resolved.root_doc,\n            request,\n        )",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-c1a6bd6945975b47fbb4b98c",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1429,
          "endLine": 1448
        },
        "sourceRevision": "efcea721f8eac86db5f605ad02af7f9f0c742f1549233715baa43c31601e365a",
        "call": {
          "sourceCallId": "call-878a7aff26af5b893259049f",
          "expression": "self._get_effective_file_doc",
          "receiver": "self",
          "receiverClass": "documents.views.DocumentViewSet",
          "arguments": [
            {
              "expression": "resolved.request_doc"
            },
            {
              "expression": "resolved.root_doc"
            },
            {
              "expression": "request"
            }
          ],
          "candidateIds": [
            "struct-c324d0c7523b878776417593"
          ],
          "resultNames": [
            "file_doc"
          ],
          "resultBinding": "file_doc"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1837,
              "endLine": 1837
            },
            "sourceCallId": "call-474c747edb2d44ff9dc93ddb",
            "candidateIds": [
              "struct-c1a6bd6945975b47fbb4b98c"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-d91c964076d74d2054543d6f",
        "anchorId": "anchor-56fad5352ec466ea695b6268",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1442,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "return serve_file(\n            doc=file_doc,\n            use_archive=not self.original_requested(request)\n            and file_doc.has_archive_version,\n            disposition=disposition,\n            follow_formatting=request.query_params.get(\"follow_formatting\", False),\n        )",
        "kind": "return-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-c1a6bd6945975b47fbb4b98c",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1429,
          "endLine": 1448
        },
        "sourceRevision": "efcea721f8eac86db5f605ad02af7f9f0c742f1549233715baa43c31601e365a",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1837,
              "endLine": 1837
            },
            "sourceCallId": "call-474c747edb2d44ff9dc93ddb",
            "candidateIds": [
              "struct-c1a6bd6945975b47fbb4b98c"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-061c14179235013f8fb178b3",
        "anchorId": "anchor-a4e848ea303537d7080cabf0",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1442,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "serve_file(\n            doc=file_doc,\n            use_archive=not self.original_requested(request)\n            and file_doc.has_archive_version,\n            disposition=disposition,\n            follow_formatting=request.query_params.get(\"follow_formatting\", False),\n        )",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-c1a6bd6945975b47fbb4b98c",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1429,
          "endLine": 1448
        },
        "sourceRevision": "efcea721f8eac86db5f605ad02af7f9f0c742f1549233715baa43c31601e365a",
        "call": {
          "sourceCallId": "call-6a2f8d15135d88065a37fbdf",
          "expression": "serve_file",
          "arguments": [
            {
              "expression": "file_doc",
              "parameterName": "doc"
            },
            {
              "expression": "not self.original_requested(request)\n            and file_doc.has_archive_version",
              "parameterName": "use_archive"
            },
            {
              "expression": "disposition",
              "parameterName": "disposition"
            },
            {
              "expression": "request.query_params.get(\"follow_formatting\", False)",
              "sourceCallId": "call-883f2888d91927d12175197b",
              "parameterName": "follow_formatting"
            }
          ],
          "candidateIds": [
            "struct-cee4399c4960908d4f7ca1fd"
          ],
          "resultNames": [],
          "resultBinding": "result-ed798ff6b24e643a"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1837,
              "endLine": 1837
            },
            "sourceCallId": "call-474c747edb2d44ff9dc93ddb",
            "candidateIds": [
              "struct-c1a6bd6945975b47fbb4b98c"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-a24f45e381728f384a39777f",
        "anchorId": "anchor-6f09571ec5d12ac63c7aee1c",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1444,
          "endLine": 1444,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "self.original_requested(request)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-c1a6bd6945975b47fbb4b98c",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1429,
          "endLine": 1448
        },
        "sourceRevision": "efcea721f8eac86db5f605ad02af7f9f0c742f1549233715baa43c31601e365a",
        "call": {
          "sourceCallId": "call-cc03ccc8ef4c67dbf98fa7de",
          "expression": "self.original_requested",
          "receiver": "self",
          "receiverClass": "documents.views.DocumentViewSet",
          "arguments": [
            {
              "expression": "request"
            }
          ],
          "candidateIds": [
            "struct-8363b0b6a86b25273c205577"
          ],
          "resultNames": [],
          "resultBinding": "result-3315b091cb66c59f"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1837,
              "endLine": 1837
            },
            "sourceCallId": "call-474c747edb2d44ff9dc93ddb",
            "candidateIds": [
              "struct-c1a6bd6945975b47fbb4b98c"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-6558140e94502c9ebcd10d79",
        "anchorId": "anchor-d904c8c5d76824a34684d48f",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1447,
          "endLine": 1447,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "request.query_params.get(\"follow_formatting\", False)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-c1a6bd6945975b47fbb4b98c",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1429,
          "endLine": 1448
        },
        "sourceRevision": "efcea721f8eac86db5f605ad02af7f9f0c742f1549233715baa43c31601e365a",
        "call": {
          "sourceCallId": "call-883f2888d91927d12175197b",
          "expression": "request.query_params.get",
          "receiver": "request.query_params",
          "arguments": [
            {
              "expression": "\"follow_formatting\"",
              "literalKnown": true,
              "literalValue": "follow_formatting"
            },
            {
              "expression": "False",
              "literalKnown": true,
              "literalValue": false
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-aa596bd5560678a7"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1837,
              "endLine": 1837
            },
            "sourceCallId": "call-474c747edb2d44ff9dc93ddb",
            "candidateIds": [
              "struct-c1a6bd6945975b47fbb4b98c"
            ],
            "state": "current",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-29f3415758b2c1f19f5a1eec",
        "anchorId": "anchor-6382981b9e6645aa52e61653",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1837,
          "endLine": 1837,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "return self.file_response(pk, request, \"attachment\")",
        "kind": "return-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-b87a4afdcea33f96a2b2fa2d",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1835,
          "endLine": 1839
        },
        "sourceRevision": "03fcc0691ed2d81d2c7dec151f5c20fb83f55ce8501b38e205ade1661a933bfb",
        "enclosingBranches": [],
        "callers": []
      },
      {
        "id": "obligation-18c6c02b4856a6f951961b22",
        "anchorId": "anchor-89884338f8e27dd5cc68eacb",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1837,
          "endLine": 1837,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "self.file_response(pk, request, \"attachment\")",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-b87a4afdcea33f96a2b2fa2d",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1835,
          "endLine": 1839
        },
        "sourceRevision": "03fcc0691ed2d81d2c7dec151f5c20fb83f55ce8501b38e205ade1661a933bfb",
        "call": {
          "sourceCallId": "call-474c747edb2d44ff9dc93ddb",
          "expression": "self.file_response",
          "receiver": "self",
          "receiverClass": "documents.views.DocumentViewSet",
          "arguments": [
            {
              "expression": "pk"
            },
            {
              "expression": "request"
            },
            {
              "expression": "\"attachment\"",
              "literalKnown": true,
              "literalValue": "attachment"
            }
          ],
          "candidateIds": [
            "struct-c1a6bd6945975b47fbb4b98c"
          ],
          "resultNames": [],
          "resultBinding": "result-a4baa301a3b30639"
        },
        "enclosingBranches": [],
        "callers": []
      },
      {
        "id": "obligation-c4b554d2cacca394439d989b",
        "anchorId": "anchor-9156da0367911009d52fa162",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1839,
          "endLine": 1839,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "raise Http404",
        "kind": "error-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-b87a4afdcea33f96a2b2fa2d",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 1835,
          "endLine": 1839
        },
        "sourceRevision": "03fcc0691ed2d81d2c7dec151f5c20fb83f55ce8501b38e205ade1661a933bfb",
        "enclosingBranches": [],
        "callers": []
      },
      {
        "id": "obligation-418feb90bcb7728304fd5a74",
        "anchorId": "anchor-193bc9f92e1c3fc97192059e",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 4948,
          "endLine": 4948,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "use_archive",
        "kind": "branch-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-cee4399c4960908d4f7ca1fd",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 4941,
          "endLine": 4995
        },
        "sourceRevision": "bbd9472ab45604e9938df2da48125f19c7f966873ea6552cde8088ebe265e48f",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1442,
              "endLine": 1448
            },
            "sourceCallId": "call-6a2f8d15135d88065a37fbdf",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1800,
              "endLine": 1805
            },
            "sourceCallId": "call-c3031e0941884e0eacf8559e",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4881,
              "endLine": 4886
            },
            "sourceCallId": "call-3bc0977575e1c5dcee6ec80c",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-ec5730e7223719d90da3eb5e",
        "anchorId": "anchor-4964ea968eb09cf6e0edccac",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 4949,
          "endLine": 4949,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "TYPE_CHECKING",
        "kind": "branch-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-cee4399c4960908d4f7ca1fd",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 4941,
          "endLine": 4995
        },
        "sourceRevision": "bbd9472ab45604e9938df2da48125f19c7f966873ea6552cde8088ebe265e48f",
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4948,
              "endLine": 4948
            },
            "anchorId": "anchor-193bc9f92e1c3fc97192059e",
            "text": "use_archive",
            "branch": "true",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1442,
              "endLine": 1448
            },
            "sourceCallId": "call-6a2f8d15135d88065a37fbdf",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1800,
              "endLine": 1805
            },
            "sourceCallId": "call-c3031e0941884e0eacf8559e",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4881,
              "endLine": 4886
            },
            "sourceCallId": "call-3bc0977575e1c5dcee6ec80c",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-f8a3f44ca6d9f9d729e83c19",
        "anchorId": "anchor-93c6d20e36c414abf6dffcc5",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 4956,
          "endLine": 4956,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "doc.get_public_filename(archive=True)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-cee4399c4960908d4f7ca1fd",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 4941,
          "endLine": 4995
        },
        "sourceRevision": "bbd9472ab45604e9938df2da48125f19c7f966873ea6552cde8088ebe265e48f",
        "call": {
          "sourceCallId": "call-25267bd6f00b9ea6d9355de6",
          "expression": "doc.get_public_filename",
          "receiver": "doc",
          "receiverClass": "documents.models.Document",
          "arguments": [
            {
              "expression": "True",
              "parameterName": "archive",
              "literalKnown": true,
              "literalValue": true
            }
          ],
          "candidateIds": [
            "struct-655864d66feb15dd10ef9ab9"
          ],
          "resultNames": [],
          "resultBinding": "result-85f748b7ec90799d"
        },
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4948,
              "endLine": 4948
            },
            "anchorId": "anchor-193bc9f92e1c3fc97192059e",
            "text": "use_archive",
            "branch": "true",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1442,
              "endLine": 1448
            },
            "sourceCallId": "call-6a2f8d15135d88065a37fbdf",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1800,
              "endLine": 1805
            },
            "sourceCallId": "call-c3031e0941884e0eacf8559e",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4881,
              "endLine": 4886
            },
            "sourceCallId": "call-3bc0977575e1c5dcee6ec80c",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-55d4dc2da19db59724107a60",
        "anchorId": "anchor-fa7aeeb80423413791ee83e7",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 4960,
          "endLine": 4960,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "TYPE_CHECKING",
        "kind": "branch-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-cee4399c4960908d4f7ca1fd",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 4941,
          "endLine": 4995
        },
        "sourceRevision": "bbd9472ab45604e9938df2da48125f19c7f966873ea6552cde8088ebe265e48f",
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4948,
              "endLine": 4948
            },
            "anchorId": "anchor-193bc9f92e1c3fc97192059e",
            "text": "use_archive",
            "branch": "false",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1442,
              "endLine": 1448
            },
            "sourceCallId": "call-6a2f8d15135d88065a37fbdf",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1800,
              "endLine": 1805
            },
            "sourceCallId": "call-c3031e0941884e0eacf8559e",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4881,
              "endLine": 4886
            },
            "sourceCallId": "call-3bc0977575e1c5dcee6ec80c",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-b5ae69c0608c5da8431c1b39",
        "anchorId": "anchor-37c953832a2955412f41cc30",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 4964,
          "endLine": 4964,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "doc.get_public_filename()",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-cee4399c4960908d4f7ca1fd",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 4941,
          "endLine": 4995
        },
        "sourceRevision": "bbd9472ab45604e9938df2da48125f19c7f966873ea6552cde8088ebe265e48f",
        "call": {
          "sourceCallId": "call-cc49df2a468901e1ad79ef9c",
          "expression": "doc.get_public_filename",
          "receiver": "doc",
          "receiverClass": "documents.models.Document",
          "arguments": [],
          "candidateIds": [
            "struct-655864d66feb15dd10ef9ab9"
          ],
          "resultNames": [],
          "resultBinding": "result-04c6877867114841"
        },
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4948,
              "endLine": 4948
            },
            "anchorId": "anchor-193bc9f92e1c3fc97192059e",
            "text": "use_archive",
            "branch": "false",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1442,
              "endLine": 1448
            },
            "sourceCallId": "call-6a2f8d15135d88065a37fbdf",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1800,
              "endLine": 1805
            },
            "sourceCallId": "call-c3031e0941884e0eacf8559e",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4881,
              "endLine": 4886
            },
            "sourceCallId": "call-3bc0977575e1c5dcee6ec80c",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-e7dd11a0a2ee02f769ac1cf2",
        "anchorId": "anchor-2a011e1b86a27405c7caf6ca",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 4967,
          "endLine": 4967,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "mime_type in {\"application/csv\", \"text/csv\"} and disposition == \"inline\"",
        "kind": "branch-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-cee4399c4960908d4f7ca1fd",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 4941,
          "endLine": 4995
        },
        "sourceRevision": "bbd9472ab45604e9938df2da48125f19c7f966873ea6552cde8088ebe265e48f",
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4948,
              "endLine": 4948
            },
            "anchorId": "anchor-193bc9f92e1c3fc97192059e",
            "text": "use_archive",
            "branch": "false",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1442,
              "endLine": 1448
            },
            "sourceCallId": "call-6a2f8d15135d88065a37fbdf",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1800,
              "endLine": 1805
            },
            "sourceCallId": "call-c3031e0941884e0eacf8559e",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4881,
              "endLine": 4886
            },
            "sourceCallId": "call-3bc0977575e1c5dcee6ec80c",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-95105d48471f0f467afef2f9",
        "anchorId": "anchor-cbfd1d71687f4ce6c6131aeb",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 4970,
          "endLine": 4970,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "mime_type in {\"text/plain\", \"text/csv\", \"application/csv\"}",
        "kind": "branch-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-cee4399c4960908d4f7ca1fd",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 4941,
          "endLine": 4995
        },
        "sourceRevision": "bbd9472ab45604e9938df2da48125f19c7f966873ea6552cde8088ebe265e48f",
        "enclosingBranches": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4948,
              "endLine": 4948
            },
            "anchorId": "anchor-193bc9f92e1c3fc97192059e",
            "text": "use_archive",
            "branch": "false",
            "stepIds": []
          }
        ],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1442,
              "endLine": 1448
            },
            "sourceCallId": "call-6a2f8d15135d88065a37fbdf",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1800,
              "endLine": 1805
            },
            "sourceCallId": "call-c3031e0941884e0eacf8559e",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4881,
              "endLine": 4886
            },
            "sourceCallId": "call-3bc0977575e1c5dcee6ec80c",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-9263672cec74fe33934b79c4",
        "anchorId": "anchor-7f130621f45f6b321c20f512",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 4973,
          "endLine": 4973,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "FileResponse(file_handle, content_type=mime_type)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-cee4399c4960908d4f7ca1fd",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 4941,
          "endLine": 4995
        },
        "sourceRevision": "bbd9472ab45604e9938df2da48125f19c7f966873ea6552cde8088ebe265e48f",
        "call": {
          "sourceCallId": "call-42735bcb42b08160dd0af393",
          "expression": "FileResponse",
          "arguments": [
            {
              "expression": "file_handle"
            },
            {
              "expression": "mime_type",
              "parameterName": "content_type"
            }
          ],
          "candidateIds": [],
          "resultNames": [
            "response"
          ],
          "resultBinding": "response"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1442,
              "endLine": 1448
            },
            "sourceCallId": "call-6a2f8d15135d88065a37fbdf",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1800,
              "endLine": 1805
            },
            "sourceCallId": "call-c3031e0941884e0eacf8559e",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4881,
              "endLine": 4886
            },
            "sourceCallId": "call-3bc0977575e1c5dcee6ec80c",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-4227956e63a714dbb50ae8f4",
        "anchorId": "anchor-0c39f5cbf3be566567c3c5cb",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 4979,
          "endLine": 4985,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "normalize(\"NFKD\", filename.replace(\",\", \"_\"))\n        .encode(\n            \"ascii\",\n            \"ignore\",\n        )\n        .decode(\"ascii\")\n        .replace(\"\\\\\", \"_\")",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-cee4399c4960908d4f7ca1fd",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 4941,
          "endLine": 4995
        },
        "sourceRevision": "bbd9472ab45604e9938df2da48125f19c7f966873ea6552cde8088ebe265e48f",
        "call": {
          "sourceCallId": "call-783175d3aeef8af3ef35c8c1",
          "expression": "normalize(\"NFKD\", filename.replace(\",\", \"_\"))\n        .encode(\n            \"ascii\",\n            \"ignore\",\n        )\n        .decode(\"ascii\")\n        .replace",
          "receiver": "normalize(\"NFKD\", filename.replace(\",\", \"_\"))\n        .encode(\n            \"ascii\",\n            \"ignore\",\n        )\n        .decode(\"ascii\")\n        ",
          "arguments": [
            {
              "expression": "\"\\\\\""
            },
            {
              "expression": "\"_\"",
              "literalKnown": true,
              "literalValue": "_"
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-e4aa7670e8c1ec48"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1442,
              "endLine": 1448
            },
            "sourceCallId": "call-6a2f8d15135d88065a37fbdf",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1800,
              "endLine": 1805
            },
            "sourceCallId": "call-c3031e0941884e0eacf8559e",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4881,
              "endLine": 4886
            },
            "sourceCallId": "call-3bc0977575e1c5dcee6ec80c",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-325d00d9b31f0decfca25635",
        "anchorId": "anchor-28c0afdabeaf7c8168afc3f3",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 4979,
          "endLine": 4986,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "normalize(\"NFKD\", filename.replace(\",\", \"_\"))\n        .encode(\n            \"ascii\",\n            \"ignore\",\n        )\n        .decode(\"ascii\")\n        .replace(\"\\\\\", \"_\")\n        .replace('\"', \"_\")",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-cee4399c4960908d4f7ca1fd",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 4941,
          "endLine": 4995
        },
        "sourceRevision": "bbd9472ab45604e9938df2da48125f19c7f966873ea6552cde8088ebe265e48f",
        "call": {
          "sourceCallId": "call-783175d3aeef8af3ef35c8c1",
          "expression": "normalize(\"NFKD\", filename.replace(\",\", \"_\"))\n        .encode(\n            \"ascii\",\n            \"ignore\",\n        )\n        .decode(\"ascii\")\n        .replace(\"\\\\\", \"_\")\n        .replace",
          "receiver": "normalize(\"NFKD\", filename.replace(\",\", \"_\"))\n        .encode(\n            \"ascii\",\n            \"ignore\",\n        )\n        .decode(\"ascii\")\n        .replace(\"\\\\\", \"_\")\n        ",
          "arguments": [
            {
              "expression": "'\"'"
            },
            {
              "expression": "\"_\"",
              "literalKnown": true,
              "literalValue": "_"
            }
          ],
          "candidateIds": [],
          "resultNames": [
            "filename_normalized"
          ],
          "resultBinding": "filename_normalized"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1442,
              "endLine": 1448
            },
            "sourceCallId": "call-6a2f8d15135d88065a37fbdf",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1800,
              "endLine": 1805
            },
            "sourceCallId": "call-c3031e0941884e0eacf8559e",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4881,
              "endLine": 4886
            },
            "sourceCallId": "call-3bc0977575e1c5dcee6ec80c",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-c9c2e6802f33ea1cca31958f",
        "anchorId": "anchor-53bb74dbae6b67f2a2d879e1",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 4979,
          "endLine": 4979,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "normalize(\"NFKD\", filename.replace(\",\", \"_\"))",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-cee4399c4960908d4f7ca1fd",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 4941,
          "endLine": 4995
        },
        "sourceRevision": "bbd9472ab45604e9938df2da48125f19c7f966873ea6552cde8088ebe265e48f",
        "call": {
          "sourceCallId": "call-783175d3aeef8af3ef35c8c1",
          "expression": "normalize",
          "arguments": [
            {
              "expression": "\"NFKD\"",
              "literalKnown": true,
              "literalValue": "NFKD"
            },
            {
              "expression": "filename.replace(\",\", \"_\")",
              "sourceCallId": "call-9ea74b11ae8f36e0d6d783c3"
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-e4aa7670e8c1ec48"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1442,
              "endLine": 1448
            },
            "sourceCallId": "call-6a2f8d15135d88065a37fbdf",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1800,
              "endLine": 1805
            },
            "sourceCallId": "call-c3031e0941884e0eacf8559e",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4881,
              "endLine": 4886
            },
            "sourceCallId": "call-3bc0977575e1c5dcee6ec80c",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-710b804c415000c833aac4f3",
        "anchorId": "anchor-7aaeba0386ce7cf5656fae78",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 4979,
          "endLine": 4984,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "normalize(\"NFKD\", filename.replace(\",\", \"_\"))\n        .encode(\n            \"ascii\",\n            \"ignore\",\n        )\n        .decode(\"ascii\")",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-cee4399c4960908d4f7ca1fd",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 4941,
          "endLine": 4995
        },
        "sourceRevision": "bbd9472ab45604e9938df2da48125f19c7f966873ea6552cde8088ebe265e48f",
        "call": {
          "sourceCallId": "call-783175d3aeef8af3ef35c8c1",
          "expression": "normalize(\"NFKD\", filename.replace(\",\", \"_\"))\n        .encode(\n            \"ascii\",\n            \"ignore\",\n        )\n        .decode",
          "receiver": "normalize(\"NFKD\", filename.replace(\",\", \"_\"))\n        .encode(\n            \"ascii\",\n            \"ignore\",\n        )\n        ",
          "arguments": [
            {
              "expression": "\"ascii\"",
              "literalKnown": true,
              "literalValue": "ascii"
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-e4aa7670e8c1ec48"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1442,
              "endLine": 1448
            },
            "sourceCallId": "call-6a2f8d15135d88065a37fbdf",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1800,
              "endLine": 1805
            },
            "sourceCallId": "call-c3031e0941884e0eacf8559e",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4881,
              "endLine": 4886
            },
            "sourceCallId": "call-3bc0977575e1c5dcee6ec80c",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-fcc772937c4579b68985f8f8",
        "anchorId": "anchor-ec3097c57899f7ab0574f813",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 4979,
          "endLine": 4983,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "normalize(\"NFKD\", filename.replace(\",\", \"_\"))\n        .encode(\n            \"ascii\",\n            \"ignore\",\n        )",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-cee4399c4960908d4f7ca1fd",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 4941,
          "endLine": 4995
        },
        "sourceRevision": "bbd9472ab45604e9938df2da48125f19c7f966873ea6552cde8088ebe265e48f",
        "call": {
          "sourceCallId": "call-783175d3aeef8af3ef35c8c1",
          "expression": "normalize(\"NFKD\", filename.replace(\",\", \"_\"))\n        .encode",
          "receiver": "normalize(\"NFKD\", filename.replace(\",\", \"_\"))\n        ",
          "arguments": [
            {
              "expression": "\"ascii\"",
              "literalKnown": true,
              "literalValue": "ascii"
            },
            {
              "expression": "\"ignore\"",
              "literalKnown": true,
              "literalValue": "ignore"
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-e4aa7670e8c1ec48"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1442,
              "endLine": 1448
            },
            "sourceCallId": "call-6a2f8d15135d88065a37fbdf",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1800,
              "endLine": 1805
            },
            "sourceCallId": "call-c3031e0941884e0eacf8559e",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4881,
              "endLine": 4886
            },
            "sourceCallId": "call-3bc0977575e1c5dcee6ec80c",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-42fa2b2849c0a637a3fa2b1c",
        "anchorId": "anchor-e4259d1c20e9c641ac6d6c20",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 4979,
          "endLine": 4979,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "filename.replace(\",\", \"_\")",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-cee4399c4960908d4f7ca1fd",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 4941,
          "endLine": 4995
        },
        "sourceRevision": "bbd9472ab45604e9938df2da48125f19c7f966873ea6552cde8088ebe265e48f",
        "call": {
          "sourceCallId": "call-9ea74b11ae8f36e0d6d783c3",
          "expression": "filename.replace",
          "receiver": "filename",
          "arguments": [
            {
              "expression": "\",\"",
              "literalKnown": true,
              "literalValue": ","
            },
            {
              "expression": "\"_\"",
              "literalKnown": true,
              "literalValue": "_"
            }
          ],
          "candidateIds": [],
          "resultNames": [],
          "resultBinding": "result-d2b24d2c697c0677"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1442,
              "endLine": 1448
            },
            "sourceCallId": "call-6a2f8d15135d88065a37fbdf",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1800,
              "endLine": 1805
            },
            "sourceCallId": "call-c3031e0941884e0eacf8559e",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4881,
              "endLine": 4886
            },
            "sourceCallId": "call-3bc0977575e1c5dcee6ec80c",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-4b89beab64d4396f99f720a5",
        "anchorId": "anchor-05f9d5a9f50d3cbcb76d30bd",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 4988,
          "endLine": 4988,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "quote(filename)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-cee4399c4960908d4f7ca1fd",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 4941,
          "endLine": 4995
        },
        "sourceRevision": "bbd9472ab45604e9938df2da48125f19c7f966873ea6552cde8088ebe265e48f",
        "call": {
          "sourceCallId": "call-8239547a09730eff3641222a",
          "expression": "quote",
          "arguments": [
            {
              "expression": "filename"
            }
          ],
          "candidateIds": [],
          "resultNames": [
            "filename_encoded"
          ],
          "resultBinding": "filename_encoded"
        },
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1442,
              "endLine": 1448
            },
            "sourceCallId": "call-6a2f8d15135d88065a37fbdf",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1800,
              "endLine": 1805
            },
            "sourceCallId": "call-c3031e0941884e0eacf8559e",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4881,
              "endLine": 4886
            },
            "sourceCallId": "call-3bc0977575e1c5dcee6ec80c",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-889aa3d65c129c35c1e74ab6",
        "anchorId": "anchor-e7f7153822e50caf541caecc",
        "source": {
          "path": "src/documents/views.py",
          "startLine": 4995,
          "endLine": 4995,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "text": "return response",
        "kind": "return-exit",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "struct-cee4399c4960908d4f7ca1fd",
          "path": "src/documents/views.py",
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
          "startLine": 4941,
          "endLine": 4995
        },
        "sourceRevision": "bbd9472ab45604e9938df2da48125f19c7f966873ea6552cde8088ebe265e48f",
        "enclosingBranches": [],
        "callers": [
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1442,
              "endLine": 1448
            },
            "sourceCallId": "call-6a2f8d15135d88065a37fbdf",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "current",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 1800,
              "endLine": 1805
            },
            "sourceCallId": "call-c3031e0941884e0eacf8559e",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          },
          {
            "source": {
              "path": "src/documents/views.py",
              "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb",
              "startLine": 4881,
              "endLine": 4886
            },
            "sourceCallId": "call-3bc0977575e1c5dcee6ec80c",
            "candidateIds": [
              "struct-cee4399c4960908d4f7ca1fd"
            ],
            "state": "caller-unread",
            "enclosingBranches": []
          }
        ]
      },
      {
        "id": "obligation-79fd080a395bdac8a2191269",
        "anchorId": "anchor-36db81333df3830f2cd8a04e",
        "source": {
          "path": "src/paperless/urls.py",
          "startLine": 75,
          "endLine": 75,
          "sha256": "a35796599a402e86a727d8e3c0b2b51a73c0dd794e0c33b3a47dd0087427c305"
        },
        "text": "api_router.register(r\"correspondents\", CorrespondentViewSet)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "route-5b49190307c515d3ccad645f",
          "path": "src/paperless/urls.py",
          "sha256": "a35796599a402e86a727d8e3c0b2b51a73c0dd794e0c33b3a47dd0087427c305",
          "startLine": 75,
          "endLine": 75
        },
        "sourceRevision": "e91785658379e148110a2d52946e8389271a37e2b06fe26c7e71f741a6dc85ec",
        "call": {
          "sourceCallId": "call-86275c096beb387fbb8d9014",
          "expression": "api_router.register",
          "receiver": "api_router",
          "receiverClass": "rest_framework.routers.DefaultRouter",
          "arguments": [
            {
              "expression": "r\"correspondents\""
            },
            {
              "expression": "CorrespondentViewSet"
            }
          ],
          "candidateIds": [
            "struct-3d3eff34a24da7055451e330"
          ],
          "resultNames": [],
          "resultBinding": "result-343d5e9fa0c5de96"
        },
        "enclosingBranches": [],
        "callers": []
      },
      {
        "id": "obligation-b5be71d978b003d1f5b91c98",
        "anchorId": "anchor-40ff80edd2f4016a6a144ca1",
        "source": {
          "path": "src/paperless/urls.py",
          "startLine": 76,
          "endLine": 76,
          "sha256": "a35796599a402e86a727d8e3c0b2b51a73c0dd794e0c33b3a47dd0087427c305"
        },
        "text": "api_router.register(r\"document_types\", DocumentTypeViewSet)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "route-8f128866c16523816aa2ebb4",
          "path": "src/paperless/urls.py",
          "sha256": "a35796599a402e86a727d8e3c0b2b51a73c0dd794e0c33b3a47dd0087427c305",
          "startLine": 76,
          "endLine": 76
        },
        "sourceRevision": "7308e8a2529de0c3bb56af6426ef9f096bcc5b63fb2442085314b1f4ff639660",
        "call": {
          "sourceCallId": "call-2cd3146d5f0afa3e4d82810a",
          "expression": "api_router.register",
          "receiver": "api_router",
          "receiverClass": "rest_framework.routers.DefaultRouter",
          "arguments": [
            {
              "expression": "r\"document_types\""
            },
            {
              "expression": "DocumentTypeViewSet"
            }
          ],
          "candidateIds": [
            "struct-3d3eff34a24da7055451e330"
          ],
          "resultNames": [],
          "resultBinding": "result-4a8dbf2dc9822f4a"
        },
        "enclosingBranches": [],
        "callers": []
      },
      {
        "id": "obligation-f9b7eed1a7d756609f7a9e9e",
        "anchorId": "anchor-89e28971e575edf4916a3d3f",
        "source": {
          "path": "src/paperless/urls.py",
          "startLine": 77,
          "endLine": 77,
          "sha256": "a35796599a402e86a727d8e3c0b2b51a73c0dd794e0c33b3a47dd0087427c305"
        },
        "text": "api_router.register(r\"documents\", UnifiedSearchViewSet)",
        "kind": "call-completion",
        "origin": "source-structure",
        "stepIds": [],
        "declarationIds": [],
        "state": "unmapped",
        "diagnostics": [],
        "function": {
          "id": "route-583a0a0cd5e3ef7f0b41671a",
          "path": "src/paperless/urls.py",
          "sha256": "a35796599a402e86a727d8e3c0b2b51a73c0dd794e0c33b3a47dd0087427c305",
          "startLine": 77,
          "endLine": 77
        },
        "sourceRevision": "114ea267c1e29b005ec5e412c417dfe50162cc1c93fae342110dda116b53592b",
        "call": {
          "sourceCallId": "call-bb9d3760a9f3dbae399b9eee",
          "expression": "api_router.register",
          "receiver": "api_router",
          "receiverClass": "rest_framework.routers.DefaultRouter",
          "arguments": [
            {
              "expression": "r\"documents\""
            },
            {
              "expression": "UnifiedSearchViewSet"
            }
          ],
          "candidateIds": [
            "struct-3d3eff34a24da7055451e330"
          ],
          "resultNames": [],
          "resultBinding": "result-671bfc5f9abeeda0"
        },
        "enclosingBranches": [],
        "callers": []
      }
    ],
    "returnBasis": {
      "kind": "structural-dependencies-with-actual-events",
      "fields": {
        "route_prefix": {
          "kinds": [
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "route_prefix",
              "op": "value",
              "source": {
                "path": "src/paperless/urls.py",
                "startLine": 74,
                "endLine": 77,
                "sha256": "a35796599a402e86a727d8e3c0b2b51a73c0dd794e0c33b3a47dd0087427c305"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "action_method": {
          "kinds": [
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "action_method",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1834,
                "endLine": 1839,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "framework_checks_precede_action": {
          "kinds": [
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "framework_checks_precede_action",
              "op": "value",
              "source": {
                "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
                "startLine": 404,
                "endLine": 421,
                "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "configured_global_permissions": {
          "kinds": [
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "configured_global_permissions",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1008,
                "endLine": 1022,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "global_model_permission": {
          "kinds": [
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "global_model_permission",
              "op": "value",
              "source": {
                "path": "src/documents/permissions.py",
                "startLine": 30,
                "endLine": 44,
                "sha256": "bb2af1efd059d69f489dea57fb579cf78967e607455820cedc2ea21226475065"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "action_permission_check_applies": {
          "kinds": [
            "finite-computation",
            "supplied-input"
          ],
          "dependencies": [
            {
              "id": "actor_present",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1421,
                "endLine": 1425,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "inherited_object_permission_invoked_for_selected_document": {
          "kinds": [
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "inherited_object_permission_invoked",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1429,
                "endLine": 1448,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "request_document": {
          "kinds": [
            "finite-computation",
            "supplied-input",
            "selection-row"
          ],
          "dependencies": [
            {
              "id": "request_doc",
              "op": "select",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1408,
                "endLine": 1415,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "request_lookup_includes_deleted": {
          "kinds": [
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "request_lookup_includes_deleted",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1429,
                "endLine": 1434,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "requested_document_is_version": {
          "kinds": [
            "finite-computation",
            "supplied-input",
            "selection-row"
          ],
          "dependencies": [
            {
              "id": "requested_document_is_version",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1388,
                "endLine": 1399,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "request_doc",
              "op": "select",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1408,
                "endLine": 1415,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "authorized_root": {
          "kinds": [
            "finite-computation",
            "supplied-input",
            "selection-row"
          ],
          "dependencies": [
            {
              "id": "root_doc",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 146,
                "endLine": 156,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "request_doc",
              "op": "select",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1408,
                "endLine": 1415,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "root_lookup",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 146,
                "endLine": 156,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "authorization_target_owner": {
          "kinds": [
            "finite-computation",
            "supplied-input",
            "selection-row"
          ],
          "dependencies": [
            {
              "id": "authorization_target_owner",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1417,
                "endLine": 1426,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "root_doc",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 146,
                "endLine": 156,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "request_doc",
              "op": "select",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1408,
                "endLine": 1415,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "root_lookup",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 146,
                "endLine": 156,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "root_permission": {
          "kinds": [
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "root_permission_name",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1421,
                "endLine": 1426,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "authorization_path": {
          "kinds": [
            "finite-computation",
            "supplied-input",
            "selection-row",
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "authorization_path",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1421,
                "endLine": 1426,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "actor_present",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1421,
                "endLine": 1425,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "owner_allows",
              "op": "value",
              "source": {
                "path": "src/documents/permissions.py",
                "startLine": 635,
                "endLine": 635,
                "sha256": "bb2af1efd059d69f489dea57fb579cf78967e607455820cedc2ea21226475065"
              },
              "outcome": "skipped",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "root_doc",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 146,
                "endLine": 156,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "request_doc",
              "op": "select",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1408,
                "endLine": 1415,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "root_lookup",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 146,
                "endLine": 156,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "object_grant_required": {
          "kinds": [
            "finite-computation",
            "supplied-input",
            "selection-row"
          ],
          "dependencies": [
            {
              "id": "object_grant_required",
              "op": "value",
              "source": {
                "path": "src/documents/permissions.py",
                "startLine": 635,
                "endLine": 635,
                "sha256": "bb2af1efd059d69f489dea57fb579cf78967e607455820cedc2ea21226475065"
              },
              "outcome": "skipped",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "owner_allows",
              "op": "value",
              "source": {
                "path": "src/documents/permissions.py",
                "startLine": 635,
                "endLine": 635,
                "sha256": "bb2af1efd059d69f489dea57fb579cf78967e607455820cedc2ea21226475065"
              },
              "outcome": "skipped",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "root_doc",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 146,
                "endLine": 156,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "request_doc",
              "op": "select",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1408,
                "endLine": 1415,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "root_lookup",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 146,
                "endLine": 156,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "actor_present",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1421,
                "endLine": 1425,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "selected_document": {
          "kinds": [
            "finite-computation",
            "supplied-input",
            "selection-row",
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "file_doc",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1375,
                "endLine": 1399,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "request_doc",
              "op": "select",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1408,
                "endLine": 1415,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "version_param",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 140,
                "endLine": 143,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "explicit_version",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 169,
                "endLine": 195,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "requested_version_id",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 175,
                "endLine": 187,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "root_doc",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 146,
                "endLine": 156,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "root_lookup",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 146,
                "endLine": 156,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "latest_visible",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 159,
                "endLine": 166,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "latest_all",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 159,
                "endLine": 166,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "selected_document_owner": {
          "kinds": [
            "finite-computation",
            "supplied-input",
            "selection-row",
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "selected_document_owner",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1437,
                "endLine": 1445,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "file_doc",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1375,
                "endLine": 1399,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "request_doc",
              "op": "select",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1408,
                "endLine": 1415,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "version_param",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 140,
                "endLine": 143,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "explicit_version",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 169,
                "endLine": 195,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "requested_version_id",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 175,
                "endLine": 187,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "root_doc",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 146,
                "endLine": 156,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "root_lookup",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 146,
                "endLine": 156,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "latest_visible",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 159,
                "endLine": 166,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "latest_all",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 159,
                "endLine": 166,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "selected_differs_from_authorized_root": {
          "kinds": [
            "finite-computation",
            "supplied-input",
            "selection-row",
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "selected_differs_from_authorized_root",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1421,
                "endLine": 1445,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "file_doc",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1375,
                "endLine": 1399,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "request_doc",
              "op": "select",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1408,
                "endLine": 1415,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "version_param",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 140,
                "endLine": 143,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "explicit_version",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 169,
                "endLine": 195,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "requested_version_id",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 175,
                "endLine": 187,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "root_doc",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 146,
                "endLine": 156,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "root_lookup",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 146,
                "endLine": 156,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "latest_visible",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 159,
                "endLine": 166,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "latest_all",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 159,
                "endLine": 166,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "selection_after_authorization": {
          "kinds": [
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "selection_after_authorization",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1429,
                "endLine": 1445,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "authorization_rechecked_for_selected_document": {
          "kinds": [
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "authorization_rechecked_for_selected_document",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1429,
                "endLine": 1445,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "version_parameter_value": {
          "kinds": [
            "finite-computation",
            "supplied-input",
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "version_param",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 140,
                "endLine": 143,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "version_parameter_present": {
          "kinds": [
            "finite-computation",
            "supplied-input",
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "version_parameter_present",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1375,
                "endLine": 1381,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "version_param",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 140,
                "endLine": 143,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "requested_version_id": {
          "kinds": [
            "finite-computation",
            "supplied-input",
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "requested_version_id",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 175,
                "endLine": 187,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "version_param",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 140,
                "endLine": 143,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "version_selection_mode": {
          "kinds": [
            "finite-computation",
            "supplied-input",
            "selection-row",
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "version_selection_mode",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1375,
                "endLine": 1399,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "request_doc",
              "op": "select",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1408,
                "endLine": 1415,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "version_param",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 140,
                "endLine": 143,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "latest_order_keys": {
          "kinds": [
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "latest_order_keys",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 23,
                "endLine": 28,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "invalid_version_outcome": {
          "kinds": [
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "invalid_version_outcome",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1375,
                "endLine": 1385,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "file_selection_precedes_representation": {
          "kinds": [
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "file_selection_precedes_representation",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1437,
                "endLine": 1445,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "original_parameter_value": {
          "kinds": [
            "finite-computation",
            "supplied-input",
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "original_param",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1368,
                "endLine": 1373,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "use_archive": {
          "kinds": [
            "finite-computation",
            "supplied-input",
            "authored-literal",
            "selection-row"
          ],
          "dependencies": [
            {
              "id": "use_archive",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1442,
                "endLine": 1447,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "original_param",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1368,
                "endLine": 1373,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "file_doc",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1375,
                "endLine": 1399,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "request_doc",
              "op": "select",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1408,
                "endLine": 1415,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "version_param",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 140,
                "endLine": 143,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "explicit_version",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 169,
                "endLine": 195,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "requested_version_id",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 175,
                "endLine": 187,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "root_doc",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 146,
                "endLine": 156,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "root_lookup",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 146,
                "endLine": 156,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "latest_visible",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 159,
                "endLine": 166,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "latest_all",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 159,
                "endLine": 166,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "selected_representation": {
          "kinds": [
            "finite-computation",
            "supplied-input",
            "authored-literal",
            "selection-row"
          ],
          "dependencies": [
            {
              "id": "selected_representation",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1442,
                "endLine": 1448,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "use_archive",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1442,
                "endLine": 1447,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "original_param",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1368,
                "endLine": 1373,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "file_doc",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1375,
                "endLine": 1399,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "request_doc",
              "op": "select",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1408,
                "endLine": 1415,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "version_param",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 140,
                "endLine": 143,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "explicit_version",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 169,
                "endLine": 195,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "requested_version_id",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 175,
                "endLine": 187,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "root_doc",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 146,
                "endLine": 156,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "root_lookup",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 146,
                "endLine": 156,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "latest_visible",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 159,
                "endLine": 166,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "latest_all",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 159,
                "endLine": 166,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "representation_changes_authorization_target": {
          "kinds": [
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "representation_changes_authorization_target",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1429,
                "endLine": 1448,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "selected_file": {
          "kinds": [
            "finite-computation",
            "supplied-input",
            "authored-literal",
            "selection-row"
          ],
          "dependencies": [
            {
              "id": "selected_file",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1442,
                "endLine": 1448,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "use_archive",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1442,
                "endLine": 1447,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "original_param",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1368,
                "endLine": 1373,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "file_doc",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1375,
                "endLine": 1399,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "request_doc",
              "op": "select",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1408,
                "endLine": 1415,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "version_param",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 140,
                "endLine": 143,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "explicit_version",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 169,
                "endLine": 195,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "requested_version_id",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 175,
                "endLine": 187,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "root_doc",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 146,
                "endLine": 156,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "root_lookup",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 146,
                "endLine": 156,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "latest_visible",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 159,
                "endLine": 166,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "latest_all",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 159,
                "endLine": 166,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "selected_content_type_rule": {
          "kinds": [
            "finite-computation",
            "supplied-input",
            "authored-literal",
            "selection-row"
          ],
          "dependencies": [
            {
              "id": "selected_content_type_rule",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 4948,
                "endLine": 4971,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "use_archive",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1442,
                "endLine": 1447,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "original_param",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1368,
                "endLine": 1373,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "file_doc",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1375,
                "endLine": 1399,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "request_doc",
              "op": "select",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1408,
                "endLine": 1415,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "version_param",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 140,
                "endLine": 143,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "explicit_version",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 169,
                "endLine": 195,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "requested_version_id",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 175,
                "endLine": 187,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "root_doc",
              "op": "value",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 146,
                "endLine": 156,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "root_lookup",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 146,
                "endLine": 156,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "latest_visible",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 159,
                "endLine": 166,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            },
            {
              "id": "latest_all",
              "op": "select",
              "source": {
                "path": "src/documents/versioning.py",
                "startLine": 159,
                "endLine": 166,
                "sha256": "de017348cbb361787d68433537bdbd39f8b56a95185a53c3cef3aa10df365766"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "follow_formatting_effect": {
          "kinds": [
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "follow_formatting_effect",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 4948,
                "endLine": 4965,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "disposition": {
          "kinds": [
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "response_disposition",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1835,
                "endLine": 1839,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "file_open_failure_outcome": {
          "kinds": [
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "file_open_failure_outcome",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1835,
                "endLine": 1839,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "runtime_auth_facts_missing": {
          "kinds": [
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "runtime_auth_facts_missing",
              "op": "value",
              "source": {
                "path": "framework/rest_framework-3.18.1/rest_framework/views.py",
                "startLine": 404,
                "endLine": 421,
                "sha256": "07d663e11faac813dd0965c337ade1cf3d6596314a37a57a21dd8e30fa56b8be"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        },
        "runtime_storage_fact_missing": {
          "kinds": [
            "authored-literal"
          ],
          "dependencies": [
            {
              "id": "runtime_storage_fact_missing",
              "op": "value",
              "source": {
                "path": "src/documents/views.py",
                "startLine": 1835,
                "endLine": 1839,
                "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
              },
              "outcome": "computed",
              "meaningOrigin": "authored-program"
            }
          ],
          "semanticSupport": "author-declared-unreviewed"
        }
      },
      "controlDependencies": [
        {
          "id": "request_doc_exists",
          "outcome": "computed",
          "source": {
            "path": "src/documents/views.py",
            "startLine": 1408,
            "endLine": 1415,
            "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
          },
          "gaps": []
        },
        {
          "id": "authorization",
          "outcome": "computed",
          "source": {
            "path": "src/documents/views.py",
            "startLine": 1421,
            "endLine": 1426,
            "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
          },
          "gaps": []
        },
        {
          "id": "file_doc_exists",
          "outcome": "computed",
          "source": {
            "path": "src/documents/views.py",
            "startLine": 1375,
            "endLine": 1386,
            "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
          },
          "gaps": []
        }
      ],
      "requiredPremises": [],
      "instruction": "Dependency kinds describe authored expressions, not source proof. An authored literal does not establish upstream behavior. Structural branches may not execute; consult actual outcomes and retain completion conditions."
    },
    "executedAssumptions": [],
    "outputFields": [
      {
        "key": "route_prefix",
        "value": "documents",
        "expression": {
          "ref": "route_prefix"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "action_method",
        "value": "GET detail download",
        "expression": {
          "ref": "action_method"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "framework_checks_precede_action",
        "value": true,
        "expression": {
          "ref": "framework_checks_precede_action"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "configured_global_permissions",
        "value": "IsAuthenticated + PaperlessObjectPermissions",
        "expression": {
          "ref": "configured_global_permissions"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "global_model_permission",
        "value": "documents.view_document",
        "expression": {
          "ref": "global_model_permission"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "action_permission_check_applies",
        "value": false,
        "expression": {
          "ref": "actor_present"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "inherited_object_permission_invoked_for_selected_document",
        "value": false,
        "expression": {
          "ref": "inherited_object_permission_invoked"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "request_document",
        "value": 10,
        "expression": {
          "field": {
            "of": {
              "ref": "request_doc"
            },
            "key": "id"
          }
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "request_lookup_includes_deleted",
        "value": true,
        "expression": {
          "ref": "request_lookup_includes_deleted"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "requested_document_is_version",
        "value": false,
        "expression": {
          "ref": "requested_document_is_version"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "authorized_root",
        "value": 10,
        "expression": {
          "field": {
            "of": {
              "ref": "root_doc"
            },
            "key": "id"
          }
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "authorization_target_owner",
        "value": 7,
        "expression": {
          "ref": "authorization_target_owner"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "root_permission",
        "value": "view_document",
        "expression": {
          "ref": "root_permission_name"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "authorization_path",
        "value": "action-check-skipped-no-user",
        "expression": {
          "ref": "authorization_path"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "object_grant_required",
        "value": null,
        "expression": {
          "ref": "object_grant_required"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "selected_document",
        "value": 11,
        "expression": {
          "field": {
            "of": {
              "ref": "file_doc"
            },
            "key": "id"
          }
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "selected_document_owner",
        "value": 9,
        "expression": {
          "ref": "selected_document_owner"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "selected_differs_from_authorized_root",
        "value": true,
        "expression": {
          "ref": "selected_differs_from_authorized_root"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "selection_after_authorization",
        "value": true,
        "expression": {
          "ref": "selection_after_authorization"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "authorization_rechecked_for_selected_document",
        "value": false,
        "expression": {
          "ref": "authorization_rechecked_for_selected_document"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "version_parameter_value",
        "value": null,
        "expression": {
          "ref": "version_param"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "version_parameter_present",
        "value": false,
        "expression": {
          "ref": "version_parameter_present"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "requested_version_id",
        "value": null,
        "expression": {
          "ref": "requested_version_id"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "version_selection_mode",
        "value": "latest-visible",
        "expression": {
          "ref": "version_selection_mode"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "latest_order_keys",
        "value": "version_index descending nulls-last, then id descending",
        "expression": {
          "ref": "latest_order_keys"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "invalid_version_outcome",
        "value": "not-found",
        "expression": {
          "ref": "invalid_version_outcome"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "file_selection_precedes_representation",
        "value": true,
        "expression": {
          "ref": "file_selection_precedes_representation"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "original_parameter_value",
        "value": "true",
        "expression": {
          "ref": "original_param"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "use_archive",
        "value": false,
        "expression": {
          "ref": "use_archive"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "selected_representation",
        "value": "original",
        "expression": {
          "ref": "selected_representation"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "representation_changes_authorization_target",
        "value": false,
        "expression": {
          "ref": "representation_changes_authorization_target"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "selected_file",
        "value": "v1-original.pdf",
        "expression": {
          "ref": "selected_file"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "selected_content_type_rule",
        "value": "selected document mime_type",
        "expression": {
          "ref": "selected_content_type_rule"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "follow_formatting_effect",
        "value": "changes response filename only, not selected document or file handle",
        "expression": {
          "ref": "follow_formatting_effect"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "disposition",
        "value": "attachment",
        "expression": {
          "ref": "response_disposition"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "file_open_failure_outcome",
        "value": "not-found",
        "expression": {
          "ref": "file_open_failure_outcome"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "runtime_auth_facts_missing",
        "value": "actual authentication, model-permission, ownership, and guardian object-grant outcomes are not supplied",
        "expression": {
          "ref": "runtime_auth_facts_missing"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      },
      {
        "key": "runtime_storage_fact_missing",
        "value": "selected file existence/readability and storage backend behavior are not supplied",
        "expression": {
          "ref": "runtime_storage_fact_missing"
        },
        "source": {
          "path": "src/documents/views.py",
          "startLine": 1429,
          "endLine": 1448,
          "sha256": "4875a5d3c0c82923d7cf8f8fb3a2b2d7fc7768a952eaa857390136b923d5b1eb"
        },
        "explanation": "Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.",
        "meaningOrigin": "author-expression-unreviewed"
      }
    ],
    "legacyStatus": "conditional",
    "semanticSupport": "unreviewed",
    "requestOperationCertified": false
  },
  "initialRevision": "e704797b1b7ba13cabd881be4cd6e6487db6f5725a4e932109b614f144dfa3ff",
  "currentRevision": "e704797b1b7ba13cabd881be4cd6e6487db6f5725a4e932109b614f144dfa3ff",
  "inputBinding": {
    "scopeQuestionId": "requested-document-and-returned-file",
    "inputQuestionId": "requested-document-and-returned-file",
    "origin": "explicit",
    "datasetPresent": true,
    "diagnostics": []
  },
  "inputs": {
    "actor": null,
    "documents": {
      "finiteRecords": 4
    },
    "related_root": null,
    "request": {
      "pk": 10,
      "original": "true"
    }
  },
  "termination": "return",
  "returned": {
    "route_prefix": "documents",
    "action_method": "GET detail download",
    "framework_checks_precede_action": true,
    "configured_global_permissions": "IsAuthenticated + PaperlessObjectPermissions",
    "global_model_permission": "documents.view_document",
    "action_permission_check_applies": false,
    "inherited_object_permission_invoked_for_selected_document": false,
    "request_document": 10,
    "request_lookup_includes_deleted": true,
    "requested_document_is_version": false,
    "authorized_root": 10,
    "authorization_target_owner": 7,
    "root_permission": "view_document",
    "authorization_path": "action-check-skipped-no-user",
    "object_grant_required": null,
    "selected_document": 11,
    "selected_document_owner": 9,
    "selected_differs_from_authorized_root": true,
    "selection_after_authorization": true,
    "authorization_rechecked_for_selected_document": false,
    "version_parameter_value": null,
    "version_parameter_present": false,
    "requested_version_id": null,
    "version_selection_mode": "latest-visible",
    "latest_order_keys": "version_index descending nulls-last, then id descending",
    "invalid_version_outcome": "not-found",
    "file_selection_precedes_representation": true,
    "original_parameter_value": "true",
    "use_archive": false,
    "selected_representation": "original",
    "representation_changes_authorization_target": false,
    "selected_file": "v1-original.pdf",
    "selected_content_type_rule": "selected document mime_type",
    "follow_formatting_effect": "changes response filename only, not selected document or file handle",
    "disposition": "attachment",
    "file_open_failure_outcome": "not-found",
    "runtime_auth_facts_missing": "actual authentication, model-permission, ownership, and guardian object-grant outcomes are not supplied",
    "runtime_storage_fact_missing": "selected file existence/readability and storage backend behavior are not supplied"
  },
  "conditions": [],
  "gaps": [
    "Further source-visible root, permission, version, and representation branches remain to be authored."
  ]
}
```

Detailed inputs and events: execution.json. In a live session use authorization_program_details with a stepId/questionId.

## 1. route_prefix — computed

The DefaultRouter registers UnifiedSearchViewSet under the documents prefix.

Executor: host; meaning: authored-program. Source: src/paperless/urls.py:74–77.

```json
{
  "outputs": {
    "value": "documents",
    "known": true
  },
  "gaps": []
}
```

## 2. action_method — computed

download is a GET detail action and delegates to file_response with attachment disposition.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1834–1839.

```json
{
  "outputs": {
    "value": "GET detail download",
    "known": true
  },
  "gaps": []
}
```

## 3. framework_checks_precede_action — computed

APIView.initial performs authentication, global permission checks, and throttling before dispatch reaches the action handler.

Executor: host; meaning: authored-program. Source: framework/rest_framework-3.18.1/rest_framework/views.py:404–421.

```json
{
  "outputs": {
    "value": true,
    "known": true
  },
  "gaps": []
}
```

## 4. configured_global_permissions — computed

DocumentViewSet configures these two global permission classes.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1008–1022.

```json
{
  "outputs": {
    "value": "IsAuthenticated + PaperlessObjectPermissions",
    "known": true
  },
  "gaps": []
}
```

## 5. global_model_permission — computed

PaperlessObjectPermissions maps GET to the model view permission; DRF checks it before dispatch.

Executor: host; meaning: authored-program. Source: src/documents/permissions.py:30–44.

```json
{
  "outputs": {
    "value": "documents.view_document",
    "known": true
  },
  "gaps": []
}
```

## 6. request_doc — computed

Author explanation not supplied.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1408–1415.

```json
{
  "outputs": {
    "value": {
      "id": 10,
      "root_document_id": null,
      "owner_id": 7,
      "version_index": null,
      "deleted": false,
      "has_archive_version": true,
      "source_file": "root-original.pdf",
      "archive_file": "root-archive.pdf"
    },
    "known": true
  },
  "gaps": []
}
```

## 7. request_doc_exists — computed

A missing pk lookup raises Http404 before root resolution or authorization.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1408–1415.

```json
{
  "inputs": {
    "test": {
      "truth": "true",
      "residual": null,
      "missingBindings": [],
      "trace": [
        {
          "op": "is-null",
          "truth": "false"
        },
        {
          "op": "not",
          "truth": "true"
        }
      ],
      "diagnostics": [],
      "valueTrace": [
        {
          "known": true,
          "value": {
            "id": 10,
            "root_document_id": null,
            "owner_id": 7,
            "version_index": null,
            "deleted": false,
            "has_archive_version": true,
            "source_file": "root-original.pdf",
            "archive_file": "root-archive.pdf"
          },
          "residual": {
            "literal": {
              "id": 10,
              "root_document_id": null,
              "owner_id": 7,
              "version_index": null,
              "deleted": false,
              "has_archive_version": true,
              "source_file": "root-original.pdf",
              "archive_file": "root-archive.pdf"
            }
          },
          "missingBindings": [],
          "diagnostics": [],
          "origin": "binding"
        }
      ]
    },
    "resource": {
      "id": 10,
      "root_document_id": null,
      "owner_id": 7,
      "version_index": null,
      "deleted": false,
      "has_archive_version": true,
      "source_file": "root-original.pdf",
      "archive_file": "root-archive.pdf"
    }
  },
  "outputs": {
    "value": true,
    "known": true
  },
  "gaps": []
}
```

## 8. request_lookup_includes_deleted — computed

file_response resolves the pk with include_deleted=True, so the request/root lookup uses the global manager rather than the visible-only manager.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1429–1434.

```json
{
  "outputs": {
    "value": true,
    "known": true
  },
  "gaps": []
}
```

## 9. root_lookup — computed

Author explanation not supplied.

Executor: host; meaning: authored-program. Source: src/documents/versioning.py:146–156.

```json
{
  "outputs": {
    "value": null,
    "known": true
  },
  "gaps": []
}
```

## 10. root_doc — computed

Author explanation not supplied.

Executor: host; meaning: authored-program. Source: src/documents/versioning.py:146–156.

```json
{
  "outputs": {
    "value": {
      "id": 10,
      "root_document_id": null,
      "owner_id": 7,
      "version_index": null,
      "deleted": false,
      "has_archive_version": true,
      "source_file": "root-original.pdf",
      "archive_file": "root-archive.pdf"
    },
    "known": true
  },
  "gaps": []
}
```

## 11. actor_present — computed

The action-level owner-aware permission call is evaluated only when request.user is not None.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1421–1425.

```json
{
  "outputs": {
    "value": false,
    "known": true
  },
  "gaps": []
}
```

## 12. permission_checker_construct — skipped

When the caller supplies a non-null user, has_perms_owner_aware constructs ObjectPermissionChecker(user).

Executor: host; meaning: authored-program. Source: src/documents/permissions.py:634–634.

```json
{
  "inputs": {
    "when": {
      "truth": "false",
      "residual": null,
      "missingBindings": [],
      "trace": [
        {
          "op": "truthy",
          "truth": "false"
        }
      ],
      "diagnostics": [],
      "valueTrace": [
        {
          "known": true,
          "value": false,
          "residual": {
            "literal": false
          },
          "missingBindings": [],
          "diagnostics": [],
          "origin": "binding"
        }
      ]
    }
  },
  "outputs": {
    "known": true,
    "value": null
  },
  "condition": {
    "op": "truthy",
    "language": "python",
    "value": {
      "binding": "actor_present"
    }
  },
  "gaps": []
}
```

## 13. permission_checker_construct_completed — skipped

Normal construction is required only on the non-null-user branch.

Executor: host; meaning: authored-program. Source: src/documents/permissions.py:634–634.

```json
{
  "inputs": {
    "when": {
      "truth": "false",
      "residual": null,
      "missingBindings": [],
      "trace": [
        {
          "op": "truthy",
          "truth": "false"
        }
      ],
      "diagnostics": [],
      "valueTrace": [
        {
          "known": true,
          "value": false,
          "residual": {
            "literal": false
          },
          "missingBindings": [],
          "diagnostics": [],
          "origin": "binding"
        }
      ]
    }
  },
  "outputs": {
    "known": true,
    "value": null
  },
  "condition": {
    "op": "truthy",
    "language": "python",
    "value": {
      "binding": "actor_present"
    }
  },
  "gaps": []
}
```

## 14. owner_allows — skipped

Within the invoked helper, an unowned root or a root owned by the user short-circuits the grant lookup.

Executor: host; meaning: authored-program. Source: src/documents/permissions.py:635–635.

```json
{
  "outputs": {
    "known": true,
    "value": null
  },
  "condition": {
    "op": "truthy",
    "language": "python",
    "value": {
      "binding": "actor_present"
    }
  },
  "gaps": []
}
```

## 15. object_grant_required — skipped

Only the non-null-user branch whose owner checks fail reaches checker.has_perm.

Executor: host; meaning: authored-program. Source: src/documents/permissions.py:635–635.

```json
{
  "outputs": {
    "known": true,
    "value": null
  },
  "condition": {
    "op": "truthy",
    "language": "python",
    "value": {
      "binding": "actor_present"
    }
  },
  "gaps": []
}
```

## 16. object_grant — skipped

checker.has_perm is the right operand of the owner-aware Python or-expression.

Executor: host; meaning: authored-program. Source: src/documents/permissions.py:635–635.

```json
{
  "inputs": {
    "when": {
      "truth": "false",
      "residual": null,
      "missingBindings": [],
      "trace": [
        {
          "op": "truthy",
          "truth": "false"
        },
        {
          "op": "all",
          "truth": "false"
        }
      ],
      "diagnostics": [],
      "valueTrace": [
        {
          "known": true,
          "value": false,
          "residual": {
            "literal": false
          },
          "missingBindings": [],
          "diagnostics": [],
          "origin": "binding"
        }
      ]
    }
  },
  "outputs": {
    "known": true,
    "value": null
  },
  "condition": {
    "op": "all",
    "args": [
      {
        "op": "truthy",
        "language": "python",
        "value": {
          "binding": "actor_present"
        }
      },
      {
        "op": "truthy",
        "language": "python",
        "value": {
          "binding": "object_grant_required"
        }
      }
    ]
  },
  "gaps": []
}
```

## 17. object_grant_completed — skipped

When invoked, has_perm must return normally before its Boolean result controls authorization.

Executor: host; meaning: authored-program. Source: src/documents/permissions.py:635–635.

```json
{
  "inputs": {
    "when": {
      "truth": "false",
      "residual": null,
      "missingBindings": [],
      "trace": [
        {
          "op": "truthy",
          "truth": "false"
        },
        {
          "op": "all",
          "truth": "false"
        }
      ],
      "diagnostics": [],
      "valueTrace": [
        {
          "known": true,
          "value": false,
          "residual": {
            "literal": false
          },
          "missingBindings": [],
          "diagnostics": [],
          "origin": "binding"
        }
      ]
    }
  },
  "outputs": {
    "known": true,
    "value": null
  },
  "condition": {
    "op": "all",
    "args": [
      {
        "op": "truthy",
        "language": "python",
        "value": {
          "binding": "actor_present"
        }
      },
      {
        "op": "truthy",
        "language": "python",
        "value": {
          "binding": "object_grant_required"
        }
      }
    ]
  },
  "gaps": []
}
```

## 18. permission_allows — computed

A null request.user skips the action-level helper; otherwise the owner-aware helper result decides.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1421–1426.

```json
{
  "outputs": {
    "value": true,
    "known": true
  },
  "gaps": []
}
```

## 19. authorization — computed

The file path returns 403 if owner-aware view permission on the root document fails.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1421–1426.

```json
{
  "inputs": {
    "test": {
      "truth": "true",
      "residual": null,
      "missingBindings": [],
      "trace": [
        {
          "op": "truthy",
          "truth": "true"
        }
      ],
      "diagnostics": [],
      "valueTrace": [
        {
          "known": true,
          "value": true,
          "residual": {
            "literal": true
          },
          "missingBindings": [],
          "diagnostics": [],
          "origin": "binding"
        }
      ]
    },
    "permission": "view_document",
    "principal": null,
    "resource": {
      "id": 10,
      "root_document_id": null,
      "owner_id": 7,
      "version_index": null,
      "deleted": false,
      "has_archive_version": true,
      "source_file": "root-original.pdf",
      "archive_file": "root-archive.pdf"
    }
  },
  "outputs": {
    "value": true,
    "known": true
  },
  "gaps": []
}
```

## 20. root_permission_name — computed

The action-specific owner-aware check applies view_document to the resolved root.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1421–1426.

```json
{
  "outputs": {
    "value": "view_document",
    "known": true
  },
  "gaps": []
}
```

## 21. authorization_path — computed

The caller short-circuits the action-level owner-aware check for a null request.user.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1421–1426.

```json
{
  "outputs": {
    "value": "action-check-skipped-no-user",
    "known": true
  },
  "gaps": []
}
```

## 22. authorization_target_owner — computed

Author explanation not supplied.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1417–1426.

```json
{
  "outputs": {
    "value": 7,
    "known": true
  },
  "gaps": []
}
```

## 23. latest_manager_selected — computed

get_latest_version_for_root chooses the visible or global manager from include_deleted before querying versions.

Executor: host; meaning: authored-program. Source: src/documents/versioning.py:164–164.

```json
{
  "outputs": {
    "value": true,
    "known": true
  },
  "gaps": []
}
```

## 24. latest_query_newest_first — computed

Related versions are ordered newest-first and the first row is selected.

Executor: host; meaning: authored-program. Source: src/documents/versioning.py:165–165.

```json
{
  "outputs": {
    "value": true,
    "known": true
  },
  "gaps": []
}
```

## 25. latest_order_keys — computed

versions_newest_first defines the precise stable ordering used before first().

Executor: host; meaning: authored-program. Source: src/documents/versioning.py:23–28.

```json
{
  "outputs": {
    "value": "version_index descending nulls-last, then id descending",
    "known": true
  },
  "gaps": []
}
```

## 26. latest_fallback_to_root — computed

When no related version exists, the root document is returned.

Executor: host; meaning: authored-program. Source: src/documents/versioning.py:166–166.

```json
{
  "outputs": {
    "value": true,
    "known": true
  },
  "gaps": []
}
```

## 27. latest_visible — computed

Author explanation not supplied.

Executor: host; meaning: authored-program. Source: src/documents/versioning.py:159–166.

```json
{
  "outputs": {
    "value": {
      "id": 11,
      "root_document_id": 10,
      "owner_id": 9,
      "version_index": 1,
      "deleted": false,
      "has_archive_version": true,
      "source_file": "v1-original.pdf",
      "archive_file": "v1-archive.pdf"
    },
    "known": true
  },
  "gaps": []
}
```

## 28. latest_all — computed

Author explanation not supplied.

Executor: host; meaning: authored-program. Source: src/documents/versioning.py:159–166.

```json
{
  "outputs": {
    "value": {
      "id": 12,
      "root_document_id": 10,
      "owner_id": 9,
      "version_index": 2,
      "deleted": true,
      "has_archive_version": false,
      "source_file": "v2-original.txt",
      "archive_file": null
    },
    "known": true
  },
  "gaps": []
}
```

## 29. version_param — computed

query_params.get('version') returns null when the key is absent; explicit null remains null and an empty string remains present and falsy.

Executor: host; meaning: authored-program. Source: src/documents/versioning.py:140–143.

```json
{
  "outputs": {
    "value": null,
    "known": true
  },
  "gaps": []
}
```

## 30. version_parameter_present — computed

A non-null value, including an empty string, makes _resolve_file_doc include deleted versions.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1375–1381.

```json
{
  "outputs": {
    "value": false,
    "known": true
  },
  "gaps": []
}
```

## 31. requested_version_id — computed

Falsy version values select latest; truthy values are converted to an integer, with invalid conversion represented by the remaining named limitation.

Executor: host; meaning: authored-program. Source: src/documents/versioning.py:175–187.

```json
{
  "outputs": {
    "value": null,
    "known": true
  },
  "gaps": []
}
```

## 32. explicit_version — computed

Author explanation not supplied.

Executor: host; meaning: authored-program. Source: src/documents/versioning.py:169–195.

```json
{
  "outputs": {
    "value": null,
    "known": true
  },
  "gaps": []
}
```

## 33. file_doc — computed

A requested version document is preserved only when the version parameter is absent; otherwise resolution uses explicit, visible-latest, or all-latest branches.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1375–1399.

```json
{
  "outputs": {
    "value": {
      "id": 11,
      "root_document_id": 10,
      "owner_id": 9,
      "version_index": 1,
      "deleted": false,
      "has_archive_version": true,
      "source_file": "v1-original.pdf",
      "archive_file": "v1-archive.pdf"
    },
    "known": true
  },
  "gaps": []
}
```

## 34. file_doc_exists — computed

Invalid, unrelated, or missing version resolution cannot reach serve_file.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1375–1386.

```json
{
  "inputs": {
    "test": {
      "truth": "true",
      "residual": null,
      "missingBindings": [],
      "trace": [
        {
          "op": "is-null",
          "truth": "false"
        },
        {
          "op": "not",
          "truth": "true"
        }
      ],
      "diagnostics": [],
      "valueTrace": [
        {
          "known": true,
          "value": {
            "id": 11,
            "root_document_id": 10,
            "owner_id": 9,
            "version_index": 1,
            "deleted": false,
            "has_archive_version": true,
            "source_file": "v1-original.pdf",
            "archive_file": "v1-archive.pdf"
          },
          "residual": {
            "literal": {
              "id": 11,
              "root_document_id": 10,
              "owner_id": 9,
              "version_index": 1,
              "deleted": false,
              "has_archive_version": true,
              "source_file": "v1-original.pdf",
              "archive_file": "v1-archive.pdf"
            }
          },
          "missingBindings": [],
          "diagnostics": [],
          "origin": "binding"
        }
      ]
    },
    "resource": {
      "id": 10,
      "root_document_id": null,
      "owner_id": 7,
      "version_index": null,
      "deleted": false,
      "has_archive_version": true,
      "source_file": "root-original.pdf",
      "archive_file": "root-archive.pdf"
    }
  },
  "outputs": {
    "value": true,
    "known": true
  },
  "gaps": []
}
```

## 35. requested_document_is_version — computed

A request whose pk names a version returns that exact version when no version query parameter is present.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1388–1399.

```json
{
  "outputs": {
    "value": false,
    "known": true
  },
  "gaps": []
}
```

## 36. version_selection_mode — computed

The mode distinguishes absent, empty, and truthy version query values.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1375–1399.

```json
{
  "outputs": {
    "value": "latest-visible",
    "known": true
  },
  "gaps": []
}
```

## 37. invalid_version_outcome — computed

An invalid version raises DRF NotFound; absent or unrelated candidates raise Http404.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1375–1385.

```json
{
  "outputs": {
    "value": "not-found",
    "known": true
  },
  "gaps": []
}
```

## 38. selected_document_owner — computed

Author explanation not supplied.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1437–1445.

```json
{
  "outputs": {
    "value": 9,
    "known": true
  },
  "gaps": []
}
```

## 39. selected_differs_from_authorized_root — computed

The root permission check precedes and is separate from effective version selection.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1421–1445.

```json
{
  "outputs": {
    "value": true,
    "known": true
  },
  "gaps": []
}
```

## 40. selection_after_authorization — computed

file_response returns on failed root authorization before calling _get_effective_file_doc.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1429–1445.

```json
{
  "outputs": {
    "value": true,
    "known": true
  },
  "gaps": []
}
```

## 41. authorization_rechecked_for_selected_document — computed

After the root check, the selected file document is passed directly to serve_file without another owner-aware check.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1429–1445.

```json
{
  "outputs": {
    "value": false,
    "known": true
  },
  "gaps": []
}
```

## 42. inherited_object_permission_invoked — computed

file_response explicitly checks the root and then selects and serves file_doc without calling get_object/check_object_permissions for file_doc.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1429–1448.

```json
{
  "outputs": {
    "value": false,
    "known": true
  },
  "gaps": []
}
```

## 43. file_selection_precedes_representation — computed

file_doc is resolved before original_requested and has_archive_version decide archive versus original.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1437–1445.

```json
{
  "outputs": {
    "value": true,
    "known": true
  },
  "gaps": []
}
```

## 44. original_param — computed

The original flag is true only when the key exists with the exact string 'true'; absent keys default to null.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1368–1373.

```json
{
  "outputs": {
    "value": "true",
    "known": true
  },
  "gaps": []
}
```

## 45. use_archive — computed

Archive is used unless original is exactly 'true', and only when the selected document has an archive version.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1442–1447.

```json
{
  "outputs": {
    "value": false,
    "known": true
  },
  "gaps": []
}
```

## 46. selected_representation — computed

serve_file receives the archive decision after the file document is selected.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1442–1448.

```json
{
  "outputs": {
    "value": "original",
    "known": true
  },
  "gaps": []
}
```

## 47. representation_changes_authorization_target — computed

original/archive selection occurs only in the later serve_file call and does not replace the checked root document.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1429–1448.

```json
{
  "outputs": {
    "value": false,
    "known": true
  },
  "gaps": []
}
```

## 48. selected_file — computed

Author explanation not supplied.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1442–1448.

```json
{
  "outputs": {
    "value": "v1-original.pdf",
    "known": true
  },
  "gaps": []
}
```

## 49. selected_content_type_rule — computed

Archive responses force application/pdf; original responses use the selected document mime type, with text charset adjustments in the source.

Executor: host; meaning: authored-program. Source: src/documents/views.py:4948–4971.

```json
{
  "outputs": {
    "value": "selected document mime_type",
    "known": true
  },
  "gaps": []
}
```

## 50. follow_formatting_effect — computed

Both representation branches choose their file handle independently of follow_formatting; that flag chooses the response filename.

Executor: host; meaning: authored-program. Source: src/documents/views.py:4948–4965.

```json
{
  "outputs": {
    "value": "changes response filename only, not selected document or file handle",
    "known": true
  },
  "gaps": []
}
```

## 51. response_disposition — computed

The Download action delegates to file_response with attachment disposition.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1835–1839.

```json
{
  "outputs": {
    "value": "attachment",
    "known": true
  },
  "gaps": []
}
```

## 52. file_open_failure_outcome — computed

The download action converts FileNotFoundError and Document.DoesNotExist into Http404.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1835–1839.

```json
{
  "outputs": {
    "value": "not-found",
    "known": true
  },
  "gaps": []
}
```

## 53. runtime_auth_facts_missing — computed

Source establishes that these runtime checks precede the action, but the finite scenario does not supply their actual deployment outcomes.

Executor: host; meaning: authored-program. Source: framework/rest_framework-3.18.1/rest_framework/views.py:404–421.

```json
{
  "outputs": {
    "value": "actual authentication, model-permission, ownership, and guardian object-grant outcomes are not supplied",
    "known": true
  },
  "gaps": []
}
```

## 54. runtime_storage_fact_missing — computed

The action catches local file/model absence, but source alone cannot establish runtime storage availability.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1835–1839.

```json
{
  "outputs": {
    "value": "selected file existence/readability and storage backend behavior are not supplied",
    "known": true
  },
  "gaps": []
}
```

## 55. result — computed

Summarize request/root authorization, version and representation selection, response construction, and runtime evidence limits.

Executor: host; meaning: authored-program. Source: src/documents/views.py:1429–1448.

```json
{
  "outputs": {
    "value": {
      "route_prefix": "documents",
      "action_method": "GET detail download",
      "framework_checks_precede_action": true,
      "configured_global_permissions": "IsAuthenticated + PaperlessObjectPermissions",
      "global_model_permission": "documents.view_document",
      "action_permission_check_applies": false,
      "inherited_object_permission_invoked_for_selected_document": false,
      "request_document": 10,
      "request_lookup_includes_deleted": true,
      "requested_document_is_version": false,
      "authorized_root": 10,
      "authorization_target_owner": 7,
      "root_permission": "view_document",
      "authorization_path": "action-check-skipped-no-user",
      "object_grant_required": null,
      "selected_document": 11,
      "selected_document_owner": 9,
      "selected_differs_from_authorized_root": true,
      "selection_after_authorization": true,
      "authorization_rechecked_for_selected_document": false,
      "version_parameter_value": null,
      "version_parameter_present": false,
      "requested_version_id": null,
      "version_selection_mode": "latest-visible",
      "latest_order_keys": "version_index descending nulls-last, then id descending",
      "invalid_version_outcome": "not-found",
      "file_selection_precedes_representation": true,
      "original_parameter_value": "true",
      "use_archive": false,
      "selected_representation": "original",
      "representation_changes_authorization_target": false,
      "selected_file": "v1-original.pdf",
      "selected_content_type_rule": "selected document mime_type",
      "follow_formatting_effect": "changes response filename only, not selected document or file handle",
      "disposition": "attachment",
      "file_open_failure_outcome": "not-found",
      "runtime_auth_facts_missing": "actual authentication, model-permission, ownership, and guardian object-grant outcomes are not supplied",
      "runtime_storage_fact_missing": "selected file existence/readability and storage backend behavior are not supplied"
    },
    "known": true
  },
  "gaps": []
}
```

## Draft proposals

0 retained proposals. Full candidates and diagnostics are in execution.json/report.json.

## Current raw draft

The raw author proposal is retained separately from the active program and candidate preview. A candidate result is not an adopted execution.

```json
{
  "draftRevision": "ea63aff2b61d5939094c4cbbb66ebec05c33c1f6bfeb14e05ea7ca8ca61cea36",
  "activeRevision": "e704797b1b7ba13cabd881be4cd6e6487db6f5725a4e932109b614f144dfa3ff",
  "candidateRevision": "ea63aff2b61d5939094c4cbbb66ebec05c33c1f6bfeb14e05ea7ca8ca61cea36",
  "candidateAdopted": true,
  "stepOrder": [
    "route_prefix",
    "action_method",
    "framework_checks_precede_action",
    "configured_global_permissions",
    "global_model_permission",
    "request_doc",
    "request_doc_exists",
    "request_lookup_includes_deleted",
    "root_lookup",
    "root_doc",
    "actor_present",
    "permission_checker_construct",
    "permission_checker_construct_completed",
    "owner_allows",
    "object_grant_required",
    "object_grant",
    "object_grant_completed",
    "permission_allows",
    "authorization",
    "root_permission_name",
    "authorization_path",
    "authorization_target_owner",
    "latest_manager_selected",
    "latest_query_newest_first",
    "latest_order_keys",
    "latest_fallback_to_root",
    "latest_visible",
    "latest_all",
    "version_param",
    "version_parameter_present",
    "requested_version_id",
    "explicit_version",
    "file_doc",
    "file_doc_exists",
    "requested_document_is_version",
    "version_selection_mode",
    "invalid_version_outcome",
    "selected_document_owner",
    "selected_differs_from_authorized_root",
    "selection_after_authorization",
    "authorization_rechecked_for_selected_document",
    "inherited_object_permission_invoked",
    "file_selection_precedes_representation",
    "original_param",
    "use_archive",
    "selected_representation",
    "representation_changes_authorization_target",
    "selected_file",
    "selected_content_type_rule",
    "follow_formatting_effect",
    "response_disposition",
    "file_open_failure_outcome",
    "runtime_auth_facts_missing",
    "runtime_storage_fact_missing",
    "result"
  ],
  "diagnostics": [
    {
      "code": "contract-coverage-reference",
      "path": "authoringTarget.coverage.4",
      "questionId": "requested-document-and-returned-file",
      "severity": "warning",
      "message": "Author coverage is unreviewed: current source reference=false; missing steps=[]; implemented claims require explicit steps. Coverage metadata does not change current execution."
    },
    {
      "code": "contract-coverage-reference",
      "path": "authoringTarget.coverage.9",
      "questionId": "requested-document-and-returned-file",
      "severity": "warning",
      "message": "Author coverage is unreviewed: current source reference=false; missing steps=[]; implemented claims require explicit steps. Coverage metadata does not change current execution."
    }
  ]
}
```

## Remaining original duties

- requested-document-and-returned-file: Explain how the request identifies the document and how the selected version and original/archive representation determine the file returned, including every relevant control branch.. Semantic coverage remains unreviewed; computed fields: route_prefix, action_method, framework_checks_precede_action, configured_global_permissions, global_model_permission, action_permission_check_applies, inherited_object_permission_invoked_for_selected_document, request_document, request_lookup_includes_deleted, requested_document_is_version, authorized_root, authorization_target_owner, root_permission, authorization_path, object_grant_required, selected_document, selected_document_owner, selected_differs_from_authorized_root, selection_after_authorization, authorization_rechecked_for_selected_document, version_parameter_value, version_parameter_present, requested_version_id, version_selection_mode, latest_order_keys, invalid_version_outcome, file_selection_precedes_representation, original_parameter_value, use_archive, selected_representation, representation_changes_authorization_target, selected_file, selected_content_type_rule, follow_formatting_effect, disposition, file_open_failure_outcome, runtime_auth_facts_missing, runtime_storage_fact_missing.
- authorization-and-selection-order: Identify the authorization checks and branches for the authenticated user, the requested document, and the selected version or original/archive representation, and state where those checks occur relative to selection of the returned file.. Semantic coverage remains unreviewed; computed fields: none.
- alternate-version-authorized-resource: Determine whether selecting another document version or choosing original versus archive changes the resource on which authorization is evaluated, or only changes the representation or file returned after authorization; distinguish all relevant branches.. Semantic coverage remains unreviewed; computed fields: none.
- missing-facts-and-conditional-conclusions: State precisely which source, configuration, deployment, ownership, or object-grant facts needed for a conclusion are unavailable, and identify the exact conclusion each missing fact blocks without assuming behavior outside the allowed evidence.. Semantic coverage remains unreviewed; computed fields: none.
